#ifndef _RGB_EFFECTS_H_
#define _RGB_EFFECTS_H_

#include <atomic>

#include <driver/gpio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <led_strip.h>

// Efek lampu modul WS2812 (8 LED). Kalau pin = GPIO_NUM_NC, semua fungsi tidak melakukan apa-apa
// (modul belum dipasang). Efek: pelangi berjalan saat joget, kilatan singkat saat musik.
class RgbEffects {
public:
    RgbEffects(gpio_num_t pin, int led_count);
    ~RgbEffects();

    bool available() const { return strip_ != nullptr; }
    void StartDance();   // pelangi berjalan "buricak burinong"
    void StartFlash(int duration_ms);  // kilatan warna-warni singkat
    void Stop();         // matikan efek dan LED

private:
    static void TaskEntry(void* arg);
    void TaskLoop();

    led_strip_handle_t strip_ = nullptr;
    int count_ = 0;
    TaskHandle_t task_ = nullptr;
    std::atomic<int> mode_{0};         // 0 = mati, 1 = joget, 2 = kilatan
    std::atomic<int> flash_ms_{0};
};

#endif  // _RGB_EFFECTS_H_
