#include "rgb_effects.h"

#include <cmath>

#include <esp_log.h>
#include <esp_timer.h>

#define TAG "RgbEffects"

namespace {
void HsvToRgb(float h, float s, float v, uint8_t* r, uint8_t* g, uint8_t* b) {
    const float c = v * s;
    const float hp = fmodf(h, 360.0f) / 60.0f;
    const float x = c * (1.0f - fabsf(fmodf(hp, 2.0f) - 1.0f));
    float rr = 0, gg = 0, bb = 0;
    if (hp < 1) { rr = c; gg = x; }
    else if (hp < 2) { rr = x; gg = c; }
    else if (hp < 3) { gg = c; bb = x; }
    else if (hp < 4) { gg = x; bb = c; }
    else if (hp < 5) { rr = x; bb = c; }
    else { rr = c; bb = x; }
    const float m = v - c;
    *r = static_cast<uint8_t>((rr + m) * 255);
    *g = static_cast<uint8_t>((gg + m) * 255);
    *b = static_cast<uint8_t>((bb + m) * 255);
}
}  // namespace

RgbEffects::RgbEffects(gpio_num_t pin, int led_count) : count_(led_count) {
    if (pin == GPIO_NUM_NC || led_count <= 0) {
        ESP_LOGI(TAG, "Modul RGB belum dipasang (pin NC), efek lampu dinonaktifkan");
        return;
    }
    led_strip_config_t strip_config = {};
    strip_config.strip_gpio_num = pin;
    strip_config.max_leds = led_count;
    strip_config.color_component_format = LED_STRIP_COLOR_COMPONENT_FMT_GRB;
    strip_config.led_model = LED_MODEL_WS2812;
    led_strip_rmt_config_t rmt_config = {};
    rmt_config.resolution_hz = 10 * 1000 * 1000;
    if (led_strip_new_rmt_device(&strip_config, &rmt_config, &strip_) != ESP_OK) {
        ESP_LOGE(TAG, "Gagal membuat strip WS2812 di GPIO %d", (int)pin);
        strip_ = nullptr;
        return;
    }
    led_strip_clear(strip_);
    xTaskCreate(&RgbEffects::TaskEntry, "rgb_fx", 3072, this, 2, &task_);
    ESP_LOGI(TAG, "Strip WS2812 siap: %d LED di GPIO %d", led_count, (int)pin);
}

RgbEffects::~RgbEffects() {
    mode_.store(0);
    if (task_ != nullptr) {
        vTaskDelete(task_);
    }
    if (strip_ != nullptr) {
        led_strip_clear(strip_);
        led_strip_del(strip_);
    }
}

void RgbEffects::StartDance() {
    if (strip_ == nullptr) return;
    mode_.store(1);
}

void RgbEffects::StartFlash(int duration_ms) {
    if (strip_ == nullptr) return;
    flash_ms_.store(duration_ms);
    mode_.store(2);
}

void RgbEffects::Stop() {
    if (strip_ == nullptr) return;
    mode_.store(0);
}

void RgbEffects::TaskEntry(void* arg) { static_cast<RgbEffects*>(arg)->TaskLoop(); }

void RgbEffects::TaskLoop() {
    int last_mode = 0;
    int64_t mode_start_us = 0;
    float phase = 0;
    while (true) {
        const int mode = mode_.load();
        const int64_t now_us = esp_timer_get_time();
        if (mode != last_mode) {
            last_mode = mode;
            mode_start_us = now_us;
            if (mode == 0) {
                led_strip_clear(strip_);
            }
        }
        if (mode == 0) {
            vTaskDelay(pdMS_TO_TICKS(80));
            continue;
        }
        if (mode == 2 && (now_us - mode_start_us) / 1000 > flash_ms_.load()) {
            mode_.store(0);
            continue;
        }
        phase += (mode == 1) ? 9.0f : 14.0f;
        for (int i = 0; i < count_; ++i) {
            uint8_t r, g, b;
            float hue;
            float val = 0.55f;
            if (mode == 1) {
                // pelangi berjalan + kedip acak (buricak burinong)
                hue = phase + i * (360.0f / count_);
                val = 0.35f + 0.35f * (0.5f + 0.5f * sinf((phase * 0.05f) + i));
            } else {
                hue = phase * 1.7f + i * 45.0f;
                val = 0.6f;
            }
            HsvToRgb(hue, 1.0f, val, &r, &g, &b);
            led_strip_set_pixel(strip_, i, r, g, b);
        }
        led_strip_refresh(strip_);
        vTaskDelay(pdMS_TO_TICKS(35));
    }
}
