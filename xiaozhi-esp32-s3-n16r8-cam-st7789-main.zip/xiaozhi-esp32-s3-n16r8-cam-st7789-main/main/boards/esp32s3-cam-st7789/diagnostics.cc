#include "diagnostics.h"

#include <cstdio>
#include <cstring>

#include <esp_chip_info.h>
#include <esp_debug_helpers.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_system.h>
#include <esp_timer.h>
#include <esp_wifi.h>
#include <esp_attr.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "application.h"
#include "device_state.h"

#define TAG "DIAG"

namespace {

constexpr uint32_t kRtcMagic = 0xD1A60001;
constexpr uint64_t kHealthPeriodUs = 5ULL * 1000 * 1000;

struct RtcBreadcrumb {
    uint32_t magic;
    uint32_t boot_count;
    uint32_t last_uptime_s;
    uint32_t last_free_heap;
    uint32_t last_min_heap;
    uint32_t last_free_internal;
    uint32_t last_largest_block;
    uint32_t restart_requested;
    char last_state[16];
    char restart_task[20];
    uint32_t checksum;
};

RTC_NOINIT_ATTR RtcBreadcrumb g_rtc;

uint32_t Checksum(const RtcBreadcrumb& b) {
    const uint8_t* p = reinterpret_cast<const uint8_t*>(&b);
    uint32_t sum = 0x5A5A5A5A;
    for (size_t i = 0; i < sizeof(RtcBreadcrumb) - sizeof(uint32_t); ++i) {
        sum = (sum << 5) + sum + p[i];
    }
    return sum;
}

void SaveBreadcrumb() { g_rtc.checksum = Checksum(g_rtc); }

const char* ResetReasonName(esp_reset_reason_t r) {
    switch (r) {
        case ESP_RST_POWERON: return "POWERON";
        case ESP_RST_EXT: return "EXT_PIN";
        case ESP_RST_SW: return "SOFTWARE (esp_restart)";
        case ESP_RST_PANIC: return "PANIC (crash/exception/assert)";
        case ESP_RST_INT_WDT: return "INT_WDT (interrupt watchdog)";
        case ESP_RST_TASK_WDT: return "TASK_WDT (task macet)";
        case ESP_RST_WDT: return "WDT (watchdog lain)";
        case ESP_RST_DEEPSLEEP: return "DEEPSLEEP";
        case ESP_RST_BROWNOUT: return "BROWNOUT (tegangan turun)";
        case ESP_RST_SDIO: return "SDIO";
        case ESP_RST_USB: return "USB";
        case ESP_RST_JTAG: return "JTAG";
        case ESP_RST_EFUSE: return "EFUSE";
        case ESP_RST_PWR_GLITCH: return "PWR_GLITCH (gangguan daya)";
        case ESP_RST_CPU_LOCKUP: return "CPU_LOCKUP";
        default: return "UNKNOWN";
    }
}

const char* ResetReasonHint(esp_reset_reason_t r) {
    switch (r) {
        case ESP_RST_POWERON:
            return "Daya baru dinyalakan. Kalau muncul sendiri saat perangkat berjalan, curigai "
                   "daya turun/putus (detektor brownout dimatikan di firmware ini).";
        case ESP_RST_SW:
            return "Restart disengaja lewat esp_restart(). Lihat baris 'RESTART DIMINTA' pada log "
                   "sebelum restart (ada task dan backtrace pemanggil).";
        case ESP_RST_PANIC:
            return "Crash. Cari 'Guru Meditation Error' / 'abort()' / 'assert' beserta Backtrace "
                   "tepat sebelum baris boot ini.";
        case ESP_RST_INT_WDT:
        case ESP_RST_TASK_WDT:
        case ESP_RST_WDT:
            return "Ada proses yang macet terlalu lama. Cari 'Task watchdog got triggered' dan "
                   "nama task yang disebut.";
        case ESP_RST_BROWNOUT:
            return "Tegangan turun saat arus besar (motor/Wi-Fi/layar). Periksa catu daya dan "
                   "kapasitor.";
        case ESP_RST_EXT:
            return "Tombol RESET atau pin EN ditekan/terganggu.";
        default:
            return "";
    }
}

const char* StateName(int s) {
    switch (s) {
        case kDeviceStateUnknown: return "unknown";
        case kDeviceStateStarting: return "starting";
        case kDeviceStateWifiConfiguring: return "wifi_config";
        case kDeviceStateIdle: return "idle";
        case kDeviceStateConnecting: return "connecting";
        case kDeviceStateListening: return "listening";
        case kDeviceStateSpeaking: return "speaking";
        case kDeviceStateNotifying: return "notifying";
        case kDeviceStateUpgrading: return "upgrading";
        case kDeviceStateActivating: return "activating";
        case kDeviceStateAudioTesting: return "audio_test";
        case kDeviceStateFatalError: return "fatal_error";
        default: return "?";
    }
}

void OnShutdown() {
    const char* task = pcTaskGetName(nullptr);
    g_rtc.restart_requested = 1;
    strlcpy(g_rtc.restart_task, task ? task : "?", sizeof(g_rtc.restart_task));
    SaveBreadcrumb();
    ESP_LOGW(TAG, "================ RESTART DIMINTA ================");
    ESP_LOGW(TAG, "Oleh task: %s | uptime: %lld s | heap bebas: %u | heap min: %u",
             task ? task : "?", (long long)(esp_timer_get_time() / 1000000),
             (unsigned)esp_get_free_heap_size(), (unsigned)esp_get_minimum_free_heap_size());
    ESP_LOGW(TAG, "Backtrace pemanggil esp_restart():");
    esp_backtrace_print(16);
    ESP_LOGW(TAG, "=================================================");
}

void HealthTick(void*) {
    const uint32_t uptime_s = (uint32_t)(esp_timer_get_time() / 1000000);
    const uint32_t free_heap = esp_get_free_heap_size();
    const uint32_t min_heap = esp_get_minimum_free_heap_size();
    const uint32_t free_int = heap_caps_get_free_size(MALLOC_CAP_INTERNAL);
    const uint32_t min_int = heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL);
    const uint32_t big_int = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL);
    const uint32_t free_psram = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
    // Hindari menyentuh Application sebelum selesai dibuat (boot masih berjalan).
    const char* state = (uptime_s < 20)
                            ? "boot"
                            : StateName((int)Application::GetInstance().GetDeviceState());

    int rssi = 0;
    wifi_ap_record_t ap = {};
    const bool wifi_ok = (esp_wifi_sta_get_ap_info(&ap) == ESP_OK);
    if (wifi_ok) {
        rssi = ap.rssi;
    }

    g_rtc.last_uptime_s = uptime_s;
    g_rtc.last_free_heap = free_heap;
    g_rtc.last_min_heap = min_heap;
    g_rtc.last_free_internal = free_int;
    g_rtc.last_largest_block = big_int;
    strlcpy(g_rtc.last_state, state, sizeof(g_rtc.last_state));
    SaveBreadcrumb();

    ESP_LOGI(TAG,
             "HEALTH up=%us state=%s heap=%u(min %u) int=%u(min %u,blk %u) psram=%u wifi=%s rssi=%d",
             (unsigned)uptime_s, state, (unsigned)free_heap, (unsigned)min_heap, (unsigned)free_int,
             (unsigned)min_int, (unsigned)big_int, (unsigned)free_psram, wifi_ok ? "ok" : "off",
             rssi);
    if (free_int < 20 * 1024) {
        ESP_LOGW(TAG, "MEMORI INTERNAL RENDAH: %u byte (blok terbesar %u)", (unsigned)free_int,
                 (unsigned)big_int);
    }
}

}  // namespace

void Diagnostics::Init() {
    const esp_reset_reason_t reason = esp_reset_reason();

    esp_chip_info_t chip = {};
    esp_chip_info(&chip);

    ESP_LOGI(TAG, "######################## BOOT ########################");
    ESP_LOGI(TAG, "Chip: ESP32-S3 rev %d, %d core | IDF %s | build %s %s", chip.revision,
             chip.cores, IDF_VER, __DATE__, __TIME__);
    ESP_LOGI(TAG, "Penyebab reset: %s", ResetReasonName(reason));
    const char* hint = ResetReasonHint(reason);
    if (hint[0] != '\0') {
        ESP_LOGI(TAG, "Petunjuk: %s", hint);
    }

    const bool valid = (g_rtc.magic == kRtcMagic) && (g_rtc.checksum == Checksum(g_rtc));
    if (valid) {
        g_rtc.boot_count++;
        ESP_LOGI(TAG, "Boot ke-%u sejak daya nyala | SESI SEBELUMNYA: uptime=%u s state=%s",
                 (unsigned)g_rtc.boot_count, (unsigned)g_rtc.last_uptime_s, g_rtc.last_state);
        ESP_LOGI(TAG, "Sesi sebelumnya: heap bebas=%u (min %u) internal=%u blok terbesar=%u",
                 (unsigned)g_rtc.last_free_heap, (unsigned)g_rtc.last_min_heap,
                 (unsigned)g_rtc.last_free_internal, (unsigned)g_rtc.last_largest_block);
        if (g_rtc.restart_requested) {
            ESP_LOGI(TAG, "Sesi sebelumnya berakhir lewat esp_restart() dari task: %s",
                     g_rtc.restart_task);
        } else if (reason == ESP_RST_SW) {
            ESP_LOGW(TAG, "Reset SW tanpa catatan restart (kemungkinan abort/panic handler).");
        } else if (reason != ESP_RST_POWERON && reason != ESP_RST_EXT) {
            ESP_LOGW(TAG, "Sesi sebelumnya berakhir TIDAK NORMAL (%s)", ResetReasonName(reason));
        }
    } else {
        memset(&g_rtc, 0, sizeof(g_rtc));
        g_rtc.magic = kRtcMagic;
        g_rtc.boot_count = 1;
        ESP_LOGI(TAG, "Boot pertama sejak daya nyala (catatan RTC kosong)");
    }
    g_rtc.restart_requested = 0;
    g_rtc.restart_task[0] = '\0';
    SaveBreadcrumb();

    ESP_LOGI(TAG, "Heap: total=%u internal=%u psram=%u bebas=%u", 
             (unsigned)heap_caps_get_total_size(MALLOC_CAP_DEFAULT),
             (unsigned)heap_caps_get_total_size(MALLOC_CAP_INTERNAL),
             (unsigned)heap_caps_get_total_size(MALLOC_CAP_SPIRAM),
             (unsigned)esp_get_free_heap_size());
    ESP_LOGI(TAG, "######################################################");

    esp_register_shutdown_handler(&OnShutdown);

    esp_timer_handle_t timer = nullptr;
    esp_timer_create_args_t args = {};
    args.callback = &HealthTick;
    args.name = "diag_health";
    args.dispatch_method = ESP_TIMER_TASK;
    if (esp_timer_create(&args, &timer) == ESP_OK) {
        esp_timer_start_periodic(timer, kHealthPeriodUs);
    }
}
