#include "robot_eyes.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>

#include <esp_log.h>
#include <esp_random.h>

#define TAG "RobotEyes"

namespace {

constexpr uint32_t kScleraColor = 0xC8FF1E;  // hijau kuning terang (glowstick)
constexpr uint32_t kPupilColor = 0x0A0A10;
constexpr uint32_t kLovePupilColor = 0xE8606E;
constexpr uint32_t kBlushColor = 0xFF7850;
constexpr int kLidOff = 90;
constexpr int kLidWidth = 180;
constexpr float kPi = 3.14159265f;

uint32_t RandRange(uint32_t lo, uint32_t hi) { return lo + esp_random() % (hi - lo + 1); }
float RandFloat(float lo, float hi) { return lo + (esp_random() % 10001) / 10000.0f * (hi - lo); }
float RandSigned() { return RandFloat(-1.0f, 1.0f); }
float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
float Lerpf(float a, float b, float t) { return a + (b - a) * t; }

uint32_t HsvToRgb(float h, float s, float v) {
    const float c = v * s;
    const float hp = fmodf(h, 360.0f) / 60.0f;
    const float x = c * (1.0f - fabsf(fmodf(hp, 2.0f) - 1.0f));
    float r = 0, g = 0, b = 0;
    if (hp < 1) { r = c; g = x; }
    else if (hp < 2) { r = x; g = c; }
    else if (hp < 3) { g = c; b = x; }
    else if (hp < 4) { g = x; b = c; }
    else if (hp < 5) { r = x; b = c; }
    else { r = c; b = x; }
    const float m = v - c;
    return (static_cast<uint32_t>((r + m) * 255) << 16) | (static_cast<uint32_t>((g + m) * 255) << 8) |
           static_cast<uint32_t>((b + m) * 255);
}

lv_obj_t* MakePlain(lv_obj_t* parent) {
    lv_obj_t* obj = lv_obj_create(parent);
    lv_obj_remove_style_all(obj);
    lv_obj_remove_flag(obj, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_remove_flag(obj, LV_OBJ_FLAG_CLICKABLE);
    return obj;
}

lv_obj_t* MakePill(lv_obj_t* parent, lv_color_t color, lv_opa_t opa) {
    lv_obj_t* obj = MakePlain(parent);
    lv_obj_set_style_bg_color(obj, color, 0);
    lv_obj_set_style_bg_opa(obj, opa, 0);
    lv_obj_set_style_radius(obj, LV_RADIUS_CIRCLE, 0);
    return obj;
}

// Hasil perhitungan geometri satu mata (piksel, koordinat layar/kotak).
struct EyeGeom {
    int bx, by;              // posisi kotak mata
    int sw, sh;              // ukuran sclera
    int px, py, pw, ph;      // pupil (lokal kotak)
    int pupil_vis;
    int pupil_love;
    int lid_vis;
    int lx0, ly0, lx1, ly1;  // titik garis kelopak
    int mask_vis;
    int mx, my, md;          // lingkaran lengkung "senang"
    int blush_vis;
    int blx, bly, blw, blh, blopa;
};

}  // namespace

RobotEyes::Mood RobotEyes::MoodFromName(const char* name) {
    if (name == nullptr) {
        return kIdle;
    }
    auto is = [name](const char* s) { return strcmp(name, s) == 0; };
    if (is("happy") || is("funny") || is("delicious") || is("silly") || is("winking") ||
        is("embarrassed")) {
        return kHappy;
    }
    if (is("loving") || is("kissy")) return kLove;
    if (is("laughing")) return kExcited;
    if (is("sad") || is("crying")) return kSad;
    if (is("angry")) return kAnnoyed;
    if (is("surprised") || is("shocked")) return kSurprised;
    if (is("thinking")) return kThinking;
    if (is("sleepy")) return kSleepy;
    if (is("confused")) return kDizzy;
    return kIdle;  // neutral, relaxed, cool, confident, dll.
}

const RobotEyes::Look& RobotEyes::LookFor(Mood mood) {
    //                  sx    sy    top   ang    curve bot   pupil lx    ly     oy   blush gaze  wob
    static const Look kLooks[] = {
        /* kIdle      */ {1.00f, 1.00f, 0.00f, 0.00f, 0.00f, 0.00f, 1.00f, 0.00f, 0.00f, 0.f, 0.0f, 1.0f, 0.0f},
        /* kHappy     */ {1.00f, 1.00f, 0.04f, 0.00f, 0.00f, 0.58f, 0.92f, 0.00f, 0.06f, -2.f, 1.0f, 0.4f, 0.0f},
        /* kSleepy    */ {1.00f, 1.00f, 0.42f, 0.00f, 0.30f, 0.06f, 0.95f, 0.10f, 0.35f, 0.f, 0.0f, 0.2f, 0.0f},
        /* kCurious   */ {1.00f, 1.00f, 0.00f, 0.00f, 0.00f, 0.00f, 1.00f, 0.70f, -0.20f, 0.f, 0.0f, 0.3f, 0.0f},
        /* kSurprised */ {1.12f, 1.16f, -0.04f, 0.00f, 0.00f, 0.00f, 0.42f, 0.00f, 0.00f, -4.f, 0.0f, 0.3f, 0.0f},
        /* kLove      */ {1.00f, 1.00f, 0.00f, 0.00f, 0.00f, 0.22f, 1.00f, 0.00f, -0.05f, 0.f, 1.0f, 0.3f, 0.0f},
        /* kDizzy     */ {1.00f, 1.00f, 0.18f, 0.00f, 0.00f, 0.08f, 0.80f, 0.00f, 0.00f, 0.f, 0.5f, 0.0f, 3.0f},
        /* kAnnoyed   */ {1.00f, 1.00f, 0.40f, 0.65f, 0.00f, 0.00f, 0.90f, 0.00f, -0.30f, 0.f, 0.0f, 0.3f, 0.0f},
        /* kSad       */ {1.00f, 1.00f, 0.26f, -0.55f, 0.15f, 0.00f, 1.05f, 0.15f, 0.50f, 3.f, 0.0f, 0.3f, 0.0f},
        /* kExcited   */ {1.05f, 1.05f, 0.00f, 0.00f, 0.00f, 0.22f, 1.25f, 0.00f, 0.00f, 0.f, 0.8f, 0.3f, 1.6f},
        /* kThinking  */ {1.00f, 1.00f, 0.30f, 0.00f, 0.00f, 0.00f, 1.00f, -0.45f, -0.55f, 0.f, 0.0f, 0.2f, 0.0f},
    };
    return kLooks[mood];
}

RobotEyes::RobotEyes(lv_obj_t* parent, int screen_w, int screen_h, lv_color_t bg_color)
    : bg_color_(bg_color), screen_w_(screen_w), screen_h_(screen_h) {
    Build(parent);
    const Look& look = LookFor(kIdle);
    cur_[0] = look.sx;
    cur_[1] = look.sy;
    cur_[6] = look.pupil;
    const uint32_t now = lv_tick_get();
    last_tick_ = now;
    next_blink_ = now + RandRange(2500, 5000);
    next_gaze_ = now + RandRange(2000, 4000);
    timer_ = lv_timer_create(&RobotEyes::TimerCb, 33, this);
    Apply(1.0f, 1.0f, 0.0f, now);
    ESP_LOGI(TAG, "Mata glowstick siap (%dx%d)", screen_w_, screen_h_);
}

RobotEyes::~RobotEyes() {
    if (root_ != nullptr) {
        lv_obj_delete(root_);  // memicu OnRootDeleted
    }
    if (timer_ != nullptr) {
        lv_timer_delete(timer_);
        timer_ = nullptr;
    }
}

void RobotEyes::OnRootDeleted(lv_event_t* e) {
    auto* self = static_cast<RobotEyes*>(lv_event_get_user_data(e));
    self->root_ = nullptr;
    for (int i = 0; i < 2; ++i) {
        self->box_[i] = self->sclera_[i] = self->pupil_[i] = self->lid_line_[i] = nullptr;
        self->mask_[i] = self->blush_[i] = nullptr;
    }
    for (auto& p : self->particles_) p.obj = nullptr;
    for (auto& r : self->rockets_) r.obj = nullptr;
    if (self->timer_ != nullptr) {
        lv_timer_delete(self->timer_);
        self->timer_ = nullptr;
    }
}

void RobotEyes::Build(lv_obj_t* parent) {
    s_ = screen_w_ / 320.0f;
    A_ = 58.0f * s_;
    B_ = 64.0f * s_;
    box_w_ = static_cast<int>(2.0f * A_ * 1.35f);
    box_h_ = static_cast<int>(2.0f * B_ * 1.35f);
    cx_[0] = screen_w_ / 2.0f - 74.0f * s_;
    cx_[1] = screen_w_ / 2.0f + 74.0f * s_;
    cy_ = screen_h_ / 2.0f;

    root_ = MakePlain(parent);
    lv_obj_set_size(root_, screen_w_, screen_h_);
    lv_obj_set_pos(root_, 0, 0);
    lv_obj_add_event_cb(root_, &RobotEyes::OnRootDeleted, LV_EVENT_DELETE, this);

    // Kembang api (paling bawah, di belakang mata)
    for (auto& r : rockets_) {
        r.obj = MakePill(root_, lv_color_white(), LV_OPA_COVER);
        lv_obj_set_size(r.obj, 4, 10);
        lv_obj_add_flag(r.obj, LV_OBJ_FLAG_HIDDEN);
    }
    for (auto& p : particles_) {
        p.obj = MakePill(root_, lv_color_white(), LV_OPA_COVER);
        lv_obj_set_size(p.obj, 5, 5);
        lv_obj_add_flag(p.obj, LV_OBJ_FLAG_HIDDEN);
    }

    // Pipi merona (di bawah mata)
    for (int i = 0; i < 2; ++i) {
        blush_[i] = MakePill(root_, lv_color_hex(kBlushColor), LV_OPA_50);
        lv_obj_add_flag(blush_[i], LV_OBJ_FLAG_HIDDEN);
    }

    // Mata
    for (int i = 0; i < 2; ++i) {
        box_[i] = MakePlain(root_);
        lv_obj_set_size(box_[i], box_w_, box_h_);

        sclera_[i] = MakePill(box_[i], lv_color_hex(kScleraColor), LV_OPA_COVER);
        pupil_[i] = MakePill(box_[i], lv_color_hex(kPupilColor), LV_OPA_COVER);

        lid_line_[i] = lv_line_create(box_[i]);
        lv_obj_remove_style_all(lid_line_[i]);
        lv_obj_set_pos(lid_line_[i], -kLidOff, -kLidOff);
        lv_obj_set_style_line_width(lid_line_[i], kLidWidth, 0);
        lv_obj_set_style_line_color(lid_line_[i], bg_color_, 0);
        lv_obj_set_style_line_opa(lid_line_[i], LV_OPA_COVER, 0);
        lv_obj_set_style_line_rounded(lid_line_[i], false, 0);
        lv_obj_remove_flag(lid_line_[i], LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_flag(lid_line_[i], LV_OBJ_FLAG_HIDDEN);

        mask_[i] = MakePill(box_[i], bg_color_, LV_OPA_COVER);
        lv_obj_add_flag(mask_[i], LV_OBJ_FLAG_HIDDEN);
    }
}

void RobotEyes::SetEmotion(const char* emotion) {
    if (dance_) {
        return;
    }
    mood_ = MoodFromName(emotion);
}

void RobotEyes::SetDance(bool on) {
    if (root_ == nullptr || dance_ == on) {
        return;
    }
    dance_ = on;
    const uint32_t now = lv_tick_get();
    if (timer_ != nullptr) {
        lv_timer_set_period(timer_, on ? 50 : 33);
    }
    if (on) {
        // Kembang api digambar di depan kelopak/lengkung mata, jadi tidak ada kotak hitam
        // yang memotong partikel.
        for (auto& r : rockets_) {
            if (r.obj) lv_obj_move_foreground(r.obj);
        }
        for (auto& p : particles_) {
            if (p.obj) lv_obj_move_foreground(p.obj);
        }
        next_launch_ = now + 300;
        focus_x_ = screen_w_ / 2.0f;
        focus_y_ = screen_h_ * 0.3f;
        focus_until_ = now + 1500;
    } else {
        for (auto& p : particles_) {
            p.active = false;
            if (p.obj) lv_obj_add_flag(p.obj, LV_OBJ_FLAG_HIDDEN);
        }
        for (auto& r : rockets_) {
            r.active = false;
            if (r.obj) lv_obj_add_flag(r.obj, LV_OBJ_FLAG_HIDDEN);
        }
        flash_ = 0;
        lv_obj_set_style_bg_opa(root_, LV_OPA_TRANSP, 0);
        mood_ = kHappy;  // senang setelah joget; emosi berikutnya dari server menggantikan
    }
}

void RobotEyes::TimerCb(lv_timer_t* timer) {
    static_cast<RobotEyes*>(lv_timer_get_user_data(timer))->Tick();
}

void RobotEyes::LaunchRocket(uint32_t now) {
    for (auto& r : rockets_) {
        if (r.active || r.obj == nullptr) continue;
        r.active = true;
        r.t = 0;
        r.dur = RandFloat(0.45f, 0.75f);
        r.x0 = RandFloat(screen_w_ * 0.15f, screen_w_ * 0.85f);
        r.y0 = static_cast<float>(screen_h_);
        r.tx = Clampf(r.x0 + RandFloat(-0.12f, 0.12f) * screen_w_, 12.0f, screen_w_ - 12.0f);
        r.ty = RandFloat(screen_h_ * 0.08f, screen_h_ * 0.42f);
        r.color = HsvToRgb(RandFloat(0, 360), 0.85f, 1.0f);
        lv_obj_set_style_bg_color(r.obj, lv_color_hex(0xFFE9A8), 0);
        lv_obj_remove_flag(r.obj, LV_OBJ_FLAG_HIDDEN);
        // pupil langsung melirik ke arah roket
        focus_x_ = r.x0;
        focus_y_ = r.y0 * 0.6f;
        focus_until_ = now + 800;
        return;
    }
}

void RobotEyes::Burst(float x, float y, uint32_t color) {
    int made = 0;
    const int want = 30;
    const float speed_scale = screen_w_ / 240.0f;
    for (auto& p : particles_) {
        if (p.active || p.obj == nullptr) continue;
        const float ang = (2.0f * kPi * made) / want + RandFloat(-0.12f, 0.12f);
        const float spd = RandFloat(60.0f, 125.0f) * speed_scale;
        p.x = x;
        p.y = y;
        p.vx = cosf(ang) * spd;
        p.vy = sinf(ang) * spd;
        p.max_life = RandFloat(0.9f, 1.5f);
        p.life = p.max_life;
        p.size = 5;
        p.active = true;
        const uint32_t c = (made % 4 == 0) ? 0xFFFFFF : color;
        lv_obj_set_style_bg_color(p.obj, lv_color_hex(c), 0);
        lv_obj_set_style_bg_opa(p.obj, LV_OPA_COVER, 0);
        lv_obj_remove_flag(p.obj, LV_OBJ_FLAG_HIDDEN);
        if (++made >= want) break;
    }
}

void RobotEyes::UpdateFireworks(float dt, uint32_t now) {
    if (dance_ && now >= next_launch_) {
        LaunchRocket(now);
        next_launch_ = now + RandRange(450, 950);
    }
    for (auto& r : rockets_) {
        if (!r.active || r.obj == nullptr) continue;
        r.t += dt / r.dur;
        if (r.t >= 1.0f) {
            r.active = false;
            lv_obj_add_flag(r.obj, LV_OBJ_FLAG_HIDDEN);
            Burst(r.tx, r.ty, r.color);
            focus_x_ = r.tx;
            focus_y_ = r.ty;
            focus_until_ = now + 1100;
            surprise_until_ = now + 380;
            continue;
        }
        const float e = 1.0f - (1.0f - r.t) * (1.0f - r.t);
        const float x = Lerpf(r.x0, r.tx, r.t);
        const float y = Lerpf(r.y0, r.ty, e);
        lv_obj_set_pos(r.obj, static_cast<int>(x) - 2, static_cast<int>(y) - 5);
        focus_x_ = x;
        focus_y_ = y;
        focus_until_ = now + 300;
    }
    for (auto& p : particles_) {
        if (!p.active || p.obj == nullptr) continue;
        p.life -= dt;
        if (p.life <= 0) {
            p.active = false;
            lv_obj_add_flag(p.obj, LV_OBJ_FLAG_HIDDEN);
            continue;
        }
        p.vy += 70.0f * dt;
        p.vx *= 0.992f;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        const float f = p.life / p.max_life;
        const int size = 2 + static_cast<int>(3.0f * f);
        if (size != p.size) {
            p.size = size;
            lv_obj_set_size(p.obj, size, size);
        }
        lv_obj_set_pos(p.obj, static_cast<int>(p.x) - size / 2, static_cast<int>(p.y) - size / 2);
        lv_obj_set_style_bg_opa(p.obj, static_cast<lv_opa_t>(Clampf(f * 1.6f, 0.0f, 1.0f) * 255), 0);
    }
    // Latar TIDAK PERNAH diganti warna: kelopak & lengkung mata digambar dengan warna latar
    // (hitam), jadi kalau latar berkedip warna, kotak kelopak dan 2 lingkaran di bawah mata
    // ikut terlihat. Efek kilat dibuang total.
    flash_ = 0.0f;
}

void RobotEyes::Tick() {
    if (root_ == nullptr) {
        return;
    }
    const uint32_t now = lv_tick_get();
    float dt = (now - last_tick_) / 1000.0f;
    last_tick_ = now;
    dt = Clampf(dt, 0.0f, 0.12f);

    Mood m = mood_;
    if (dance_) {
        m = (now < surprise_until_) ? kSurprised : kHappy;
    }
    const Look& look = LookFor(m);

    // Kedip otomatis
    float blink_mult = 1.0f;
    if (blink_start_ == 0 && now >= next_blink_) {
        blink_start_ = now ? now : 1;
    }
    if (blink_start_ != 0) {
        const float p = (now - blink_start_) / 180.0f;
        if (p >= 1.0f) {
            blink_start_ = 0;
            next_blink_ = now + RandRange(2800, 6500);
        } else {
            const float tri = p < 0.5f ? p * 2.0f : (1.0f - p) * 2.0f;
            blink_mult = 1.0f - 0.92f * tri;
        }
    }

    // Melirik acak (tidak saat joget)
    if (!dance_ && now >= next_gaze_) {
        if (esp_random() % 100 < 40) {
            gaze_tx_ = 0;
            gaze_ty_ = 0;
        } else {
            gaze_tx_ = RandSigned() * 0.8f;
            gaze_ty_ = RandSigned() * 0.4f;
        }
        next_gaze_ = now + RandRange(2200, 5500);
    }

    const float k = 1.0f - expf(-dt * 14.0f);
    const float kg = 1.0f - expf(-dt * 8.0f);
    gaze_x_ += (gaze_tx_ * look.gaze - gaze_x_) * kg;
    gaze_y_ += (gaze_ty_ * look.gaze - gaze_y_) * kg;
    dance_k_ += ((dance_ ? 1.0f : 0.0f) - dance_k_) * (1.0f - expf(-dt * 5.0f));

    float lx = look.lx + gaze_x_;
    float ly = look.ly + gaze_y_;
    if (m == kDizzy) {
        swirl_ += dt * 10.0f;
        lx = sinf(swirl_) * 0.85f;
        ly = cosf(swirl_) * 0.5f;
    }
    if (dance_ && now < focus_until_) {
        // pupil menatap ledakan / roket
        const float eye_y = screen_h_ * 0.70f;
        lx = Clampf((focus_x_ - screen_w_ / 2.0f) / (screen_w_ * 0.30f), -1.0f, 1.0f);
        ly = Clampf((focus_y_ - eye_y) / (screen_h_ * 0.30f), -1.0f, 1.0f);
    }

    const float target[11] = {look.sx, look.sy, look.top, look.ang, look.curve, look.bot,
                              look.pupil, lx, ly, look.oy, look.blush};
    for (int i = 0; i < 11; ++i) {
        const float rate = (i == 7 || i == 8) ? (dance_ ? 0.45f : k) : k;
        cur_[i] += (target[i] - cur_[i]) * rate;
    }

    if (dance_ || dance_k_ > 0.02f || flash_ > 0.0f) {
        UpdateFireworks(dt, now);
    } else {
        // pastikan partikel yang tersisa hilang
        for (auto& p : particles_) {
            if (p.active) UpdateFireworks(dt, now);
        }
    }

    const float wob = look.wobble != 0.0f ? sinf(now / 26.0f) * look.wobble : 0.0f;
    cur_[11] = wob;
    Apply(1.0f, blink_mult, dance_k_, now);
}

void RobotEyes::Apply(float sx_both, float sy_both, float dance_k, uint32_t now) {
    if (root_ == nullptr) {
        return;
    }
    (void)sx_both;
    const float gs = 1.0f - 0.52f * dance_k;  // ukuran mata mengecil saat joget
    const float eye_cy = cy_ + dance_k * (screen_h_ * 0.70f - cy_);
    const float half_sp = Lerpf(74.0f * s_, 40.0f * s_, dance_k);
    const float bounce = dance_k * sinf(now / 1000.0f * 2.0f * kPi * 2.0f) * 3.0f;
    const float wob = cur_[11];

    Mood m = mood_;
    if (dance_) m = (now < surprise_until_) ? kSurprised : kHappy;

    EyeGeom g[2];
    memset(g, 0, sizeof(g));

    for (int i = 0; i < 2; ++i) {
        const int side = (i == 0) ? 1 : -1;
        float sx = cur_[0], sy = cur_[1], top = cur_[2];
        if (m == kCurious) {
            const bool wide = (cur_[7] >= 0) ? (i == 1) : (i == 0);
            if (wide) { sx *= 1.06f; sy *= 1.09f; top = 0.0f; }
            else { top = 0.28f; }
        }
        const float ang = cur_[3], curve = cur_[4], bot = cur_[5], pupil = cur_[6];
        const float lx = cur_[7], ly = cur_[8];
        const float oy = cur_[9] * s_;

        const float ex = screen_w_ / 2.0f + (i == 0 ? -half_sp : half_sp) + wob;
        const float ey = eye_cy + oy + bounce;

        const float a = A_ * sx * gs;
        const float b = std::max(2.0f, B_ * sy * gs * sy_both);  // sy_both = kedip

        g[i].bx = static_cast<int>(ex - box_w_ / 2.0f);
        g[i].by = static_cast<int>(ey - box_h_ / 2.0f);
        g[i].sw = std::max(4, static_cast<int>(2.0f * a));
        g[i].sh = std::max(4, static_cast<int>(2.0f * b));

        // Pupil celah
        const float ax = Clampf(22.0f * (0.36f + (1.0f - pupil) * 0.9f), 22.0f * 0.18f, 22.0f * 0.95f) *
                         s_ * sx * gs;
        const float ay = 22.0f * 1.3f * s_ * sy * gs * (sy_both > 0.4f ? 1.0f : sy_both);
        const float trav = 0.5f + 0.3f * dance_k;
        const bool love = (m == kLove);
        float pw = 2.0f * ax, ph = 2.0f * ay;
        if (love) {
            pw = ph = 2.0f * 22.0f * s_ * 0.95f * gs;
        }
        const float px = lx * a * trav;
        const float py = ly * b * 0.42f;
        g[i].pw = std::max(2, static_cast<int>(pw));
        g[i].ph = std::max(2, static_cast<int>(ph));
        g[i].px = static_cast<int>(box_w_ / 2.0f + px - pw / 2.0f);
        g[i].py = static_cast<int>(box_h_ / 2.0f + py - ph / 2.0f);
        g[i].pupil_vis = sy_both > 0.3f ? 1 : 0;
        g[i].pupil_love = love ? 1 : 0;

        // Kelopak atas: garis tebal bewarna latar
        auto top_q = [&](float nx) {
            return -1.0f + 2.1f * top + ang * 0.55f * side * nx - curve * 0.5f * 0.33f;
        };
        const float ql = top_q(-1.0f);
        const float qr = top_q(1.0f);
        if (std::max(ql, qr) > -0.97f) {
            const float cxl = box_w_ / 2.0f - a;
            const float cxr = box_w_ / 2.0f + a;
            const float yl = box_h_ / 2.0f + b * ql;
            const float yr = box_h_ / 2.0f + b * qr;
            const float slope = (yr - yl) / (cxr - cxl);
            const float xa = -40.0f;
            const float xb = box_w_ + 40.0f;
            const float ya = yl + slope * (xa - cxl);
            const float yb = yl + slope * (xb - cxl);
            const float dx = xb - xa;
            const float dy = yb - ya;
            const float len = sqrtf(dx * dx + dy * dy);
            const float ux = dy / len;
            const float uy = -dx / len;
            const float half = kLidWidth * 0.5f;
            g[i].lid_vis = 1;
            g[i].lx0 = static_cast<int>(lroundf(xa + ux * half + kLidOff));
            g[i].ly0 = static_cast<int>(lroundf(ya + uy * half + kLidOff));
            g[i].lx1 = static_cast<int>(lroundf(xb + ux * half + kLidOff));
            g[i].ly1 = static_cast<int>(lroundf(yb + uy * half + kLidOff));
        }

        // Lengkung "senang"/bawah: lingkaran bewarna latar naik dari bawah
        if (bot > 0.02f) {
            const float sag = std::max(1.0f, 0.55f * bot * b);
            const float r = std::min(600.0f, (a * a + sag * sag) / (2.0f * sag));
            const float ytop = box_h_ / 2.0f + b * (1.0f - 1.35f * bot);
            g[i].mask_vis = 1;
            g[i].md = static_cast<int>(2.0f * r);
            g[i].mx = static_cast<int>(box_w_ / 2.0f - r);
            g[i].my = static_cast<int>(ytop);
        }

        // Pipi merona
        const float bl = cur_[10];
        if (bl > 0.03f) {
            g[i].blush_vis = 1;
            g[i].blw = std::max(6, static_cast<int>(30.0f * s_ * gs));
            g[i].blh = std::max(5, static_cast<int>(22.0f * s_ * gs));
            const float outward = (i == 0) ? -0.50f : 0.50f;
            g[i].blx = static_cast<int>(ex + outward * a - g[i].blw / 2.0f);
            g[i].bly = static_cast<int>(ey + b * 0.80f - g[i].blh / 2.0f);
            g[i].blopa = static_cast<int>(Clampf(bl, 0.0f, 1.0f) * 140.0f);
        }
    }

    if (applied_.valid && memcmp(applied_.v, g, std::min(sizeof(g), sizeof(applied_.v))) == 0 &&
        sizeof(g) <= sizeof(applied_.v)) {
        return;
    }
    if (sizeof(g) <= sizeof(applied_.v)) {
        memcpy(applied_.v, g, sizeof(g));
        applied_.valid = true;
    }

    for (int i = 0; i < 2; ++i) {
        lv_obj_set_pos(box_[i], g[i].bx, g[i].by);
        lv_obj_set_size(sclera_[i], g[i].sw, g[i].sh);
        lv_obj_set_pos(sclera_[i], box_w_ / 2 - g[i].sw / 2, box_h_ / 2 - g[i].sh / 2);

        if (g[i].pupil_vis) {
            lv_obj_set_size(pupil_[i], g[i].pw, g[i].ph);
            lv_obj_set_pos(pupil_[i], g[i].px, g[i].py);
            lv_obj_set_style_bg_color(
                pupil_[i], lv_color_hex(g[i].pupil_love ? kLovePupilColor : kPupilColor), 0);
            lv_obj_remove_flag(pupil_[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(pupil_[i], LV_OBJ_FLAG_HIDDEN);
        }

        if (g[i].lid_vis) {
            lid_pts_[i][0].x = static_cast<lv_value_precise_t>(g[i].lx0);
            lid_pts_[i][0].y = static_cast<lv_value_precise_t>(g[i].ly0);
            lid_pts_[i][1].x = static_cast<lv_value_precise_t>(g[i].lx1);
            lid_pts_[i][1].y = static_cast<lv_value_precise_t>(g[i].ly1);
            lv_line_set_points(lid_line_[i], lid_pts_[i], 2);
            lv_obj_remove_flag(lid_line_[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(lid_line_[i], LV_OBJ_FLAG_HIDDEN);
        }

        if (g[i].mask_vis) {
            lv_obj_set_size(mask_[i], g[i].md, g[i].md);
            lv_obj_set_pos(mask_[i], g[i].mx, g[i].my);
            lv_obj_remove_flag(mask_[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(mask_[i], LV_OBJ_FLAG_HIDDEN);
        }

        if (g[i].blush_vis) {
            lv_obj_set_size(blush_[i], g[i].blw, g[i].blh);
            lv_obj_set_pos(blush_[i], g[i].blx, g[i].bly);
            lv_obj_set_style_bg_opa(blush_[i], static_cast<lv_opa_t>(g[i].blopa), 0);
            lv_obj_remove_flag(blush_[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(blush_[i], LV_OBJ_FLAG_HIDDEN);
        }
    }
}

void RobotEyes::SetFireworksVisible(bool) {}
