#include "robot_eyes.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>

#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_random.h>

#define TAG "RobotEyes"

namespace {

constexpr int kGlow = 10;          // lebar cahaya di luar mata (piksel)
constexpr uint32_t kTickMs = 33;   // ~30 fps
constexpr int kLidOff = 90;        // offset koordinat garis kelopak (supaya tidak negatif)
constexpr int kLidWidth = 170;     // tebal garis kelopak
constexpr uint8_t kRecolorOpa = 200;
constexpr float kPi = 3.14159265f;

uint32_t RandRange(uint32_t lo, uint32_t hi) { return lo + esp_random() % (hi - lo + 1); }

float RandSigned() { return (static_cast<float>(esp_random() % 2001) / 1000.0f) - 1.0f; }

float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

lv_obj_t* MakePlain(lv_obj_t* parent) {
    lv_obj_t* obj = lv_obj_create(parent);
    lv_obj_remove_style_all(obj);
    lv_obj_remove_flag(obj, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_remove_flag(obj, LV_OBJ_FLAG_CLICKABLE);
    return obj;
}

lv_obj_t* MakePill(lv_obj_t* parent, lv_color_t color, lv_opa_t opa) {
    lv_obj_t* obj = MakePlain(parent);
    lv_obj_set_style_bg_color(obj, color, 0);
    lv_obj_set_style_bg_opa(obj, opa, 0);
    lv_obj_set_style_radius(obj, LV_RADIUS_CIRCLE, 0);
    return obj;
}

}  // namespace

RobotEyes::Mood RobotEyes::MoodFromName(const char* name) {
    if (name == nullptr) {
        return kNeutral;
    }
    auto is = [name](const char* s) { return strcmp(name, s) == 0; };
    if (is("happy") || is("funny") || is("delicious") || is("silly") || is("winking") ||
        is("embarrassed")) {
        return kHappy;
    }
    if (is("loving") || is("kissy")) {
        return kLove;
    }
    if (is("laughing")) {
        return kLaugh;
    }
    if (is("sad") || is("crying")) {
        return kSad;
    }
    if (is("angry")) {
        return kAngry;
    }
    if (is("surprised") || is("shocked")) {
        return kSurprised;
    }
    if (is("thinking")) {
        return kThinking;
    }
    if (is("sleepy")) {
        return kSleepy;
    }
    if (is("confused")) {
        return kConfused;
    }
    return kNeutral;  // neutral, relaxed, cool, confident, dll.
}

const RobotEyes::Look& RobotEyes::LookFor(Mood mood) {
    //                       sx    sy   lo    li   mask  ox    oy   gaze  shx  shy  color
    static const Look kLooks[] = {
        /* kNeutral   */ {1.00f, 1.00f, 0.00f, 0.00f, 0.0f, 0.f, 0.f, 1.0f, 0.f, 0.f, 0x1F8FFF},
        /* kHappy     */ {1.00f, 1.00f, 0.00f, 0.00f, 1.0f, 0.f, 0.f, 0.4f, 0.f, 0.f, 0xFFB400},
        /* kLove      */ {1.00f, 1.00f, 0.00f, 0.00f, 1.0f, 0.f, 0.f, 0.3f, 0.f, 0.f, 0xFF5FA2},
        /* kLaugh     */ {1.00f, 1.00f, 0.00f, 0.00f, 1.0f, 0.f, 0.f, 0.0f, 0.f, 3.5f, 0xFFB400},
        /* kSad       */ {1.00f, 0.95f, 0.75f, 0.00f, 0.0f, 0.f, 7.f, 0.3f, 0.f, 0.f, 0x2E5BFF},
        /* kAngry     */ {1.00f, 1.00f, 0.05f, 1.00f, 0.0f, 0.f, 0.f, 0.3f, 0.f, 0.f, 0xFF3B30},
        /* kSurprised */ {1.12f, 1.12f, 0.00f, 0.00f, 0.0f, 0.f, 0.f, 0.3f, 0.f, 0.f, 0x5FE3FF},
        /* kThinking  */ {1.00f, 1.00f, 0.00f, 0.00f, 0.0f, -10.f, -12.f, 0.2f, 0.f, 0.f, 0x1FD6B5},
        /* kSleepy    */ {1.00f, 0.90f, 0.55f, 0.50f, 0.0f, 0.f, 4.f, 0.2f, 0.f, 0.f, 0x7A5CFF},
        /* kConfused  */ {1.00f, 1.00f, 0.00f, 0.00f, 0.0f, 0.f, 0.f, 0.5f, 5.f, 0.f, 0xFF8A00},
    };
    return kLooks[mood];
}

RobotEyes::RobotEyes(lv_obj_t* parent, int screen_w, int screen_h, lv_color_t bg_color)
    : bg_color_(bg_color), screen_w_(screen_w), screen_h_(screen_h) {
    ry_ = static_cast<int>(screen_h * 0.22f);
    rx_ = static_cast<int>(ry_ * 0.55f);
    sprite_w_ = 2 * (rx_ + kGlow);
    sprite_h_ = 2 * (ry_ + kGlow);
    const int gap = 14;
    cx_[0] = screen_w / 2 - (rx_ + gap / 2);
    cx_[1] = screen_w / 2 + (rx_ + gap / 2);
    cy_ = screen_h / 2;

    BuildSprite();
    if (sprite_buf_ == nullptr) {
        ESP_LOGE(TAG, "Gagal mengalokasikan sprite mata (%d x %d)", sprite_w_, sprite_h_);
        return;
    }
    BuildEyes(parent);

    const Look& look = LookFor(kNeutral);
    cur_r_ = (look.color >> 16) & 0xFF;
    cur_g_ = (look.color >> 8) & 0xFF;
    cur_b_ = look.color & 0xFF;

    const uint32_t now = lv_tick_get();
    last_tick_ = now;
    next_blink_ = now + RandRange(2500, 5000);
    next_gaze_ = now + RandRange(2000, 4000);

    ApplyLook(look.sx, look.sy, look.ox, look.oy, look.lid_out, look.lid_in, look.mask,
              look.color);
    timer_ = lv_timer_create(&RobotEyes::TimerCb, kTickMs, this);
    ESP_LOGI(TAG, "Mata siap (%dx%d, sprite %dx%d)", rx_ * 2, ry_ * 2, sprite_w_, sprite_h_);
}

RobotEyes::~RobotEyes() {
    if (root_ != nullptr) {
        lv_obj_delete(root_);  // memicu OnRootDeleted
    }
    if (timer_ != nullptr) {
        lv_timer_delete(timer_);
        timer_ = nullptr;
    }
    if (sprite_buf_ != nullptr) {
        heap_caps_free(sprite_buf_);
        sprite_buf_ = nullptr;
    }
}

void RobotEyes::OnRootDeleted(lv_event_t* e) {
    auto* self = static_cast<RobotEyes*>(lv_event_get_user_data(e));
    self->root_ = nullptr;
    for (int i = 0; i < 2; ++i) {
        self->img_[i] = nullptr;
        self->hl_big_[i] = nullptr;
        self->hl_small_[i] = nullptr;
        self->lid_box_[i] = nullptr;
        self->lid_line_[i] = nullptr;
        self->mask_[i] = nullptr;
    }
    if (self->timer_ != nullptr) {
        lv_timer_delete(self->timer_);
        self->timer_ = nullptr;
    }
}

void RobotEyes::BuildSprite() {
    const int W = sprite_w_;
    const int H = sprite_h_;
    const size_t size = static_cast<size_t>(W) * H * 4;
    sprite_buf_ = static_cast<uint8_t*>(heap_caps_malloc(size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (sprite_buf_ == nullptr) {
        sprite_buf_ = static_cast<uint8_t*>(heap_caps_malloc(size, MALLOC_CAP_8BIT));
    }
    if (sprite_buf_ == nullptr) {
        return;
    }

    const float cx = (W - 1) * 0.5f;
    const float cy = (H - 1) * 0.5f;
    const float rx = static_cast<float>(rx_);
    const float ry = static_cast<float>(ry_);
    const float rxo = rx + kGlow;
    const float ryo = ry + kGlow;
    const float hx = -0.16f * rx;  // pusat gradasi (agak ke kiri-atas)
    const float hy = -0.30f * ry;

    for (int y = 0; y < H; ++y) {
        for (int x = 0; x < W; ++x) {
            const float dx = x - cx;
            const float dy = y - cy;
            const float r = sqrtf(dx * dx + dy * dy);

            float r_body = rx;  // jari-jari badan mata searah piksel ini
            float r_out = rxo;
            if (r > 0.0001f) {
                const float ux = dx / r;
                const float uy = dy / r;
                r_body = 1.0f / sqrtf((ux / rx) * (ux / rx) + (uy / ry) * (uy / ry));
                r_out = 1.0f / sqrtf((ux / rxo) * (ux / rxo) + (uy / ryo) * (uy / ryo));
            }

            // Badan mata: gradasi radial abu-abu (terang di tengah, gelap di tepi).
            const float tx = (dx - hx) / (rx * 1.5f);
            const float ty = (dy - hy) / (ry * 1.5f);
            const float t = Clampf(sqrtf(tx * tx + ty * ty), 0.0f, 1.0f);
            const float body_gray = 255.0f - t * (255.0f - 80.0f);
            const float cover = Clampf(r_body - r + 0.5f, 0.0f, 1.0f);  // anti-alias tepi

            // Cahaya di luar mata.
            float glow_a = 0.0f;
            if (r > r_body - 1.0f && r_out > r_body) {
                const float f = Clampf((r - r_body) / (r_out - r_body), 0.0f, 1.0f);
                glow_a = 70.0f * powf(1.0f - f, 1.6f);
            }
            const float glow_gray = 210.0f;

            const float a_body = cover * 255.0f;
            const float a_glow = (1.0f - cover) * glow_a;
            const float alpha = a_body + a_glow;
            float gray = 0.0f;
            if (alpha > 0.5f) {
                gray = (a_body * body_gray + a_glow * glow_gray) / alpha;
            }

            uint8_t* p = sprite_buf_ + (static_cast<size_t>(y) * W + x) * 4;
            const uint8_t g8 = static_cast<uint8_t>(Clampf(gray, 0.0f, 255.0f));
            p[0] = g8;  // B
            p[1] = g8;  // G
            p[2] = g8;  // R
            p[3] = static_cast<uint8_t>(Clampf(alpha, 0.0f, 255.0f));  // A
        }
    }

    memset(&sprite_dsc_, 0, sizeof(sprite_dsc_));
    sprite_dsc_.header.magic = LV_IMAGE_HEADER_MAGIC;
    sprite_dsc_.header.cf = LV_COLOR_FORMAT_ARGB8888;
    sprite_dsc_.header.w = W;
    sprite_dsc_.header.h = H;
    sprite_dsc_.header.stride = W * 4;
    sprite_dsc_.data_size = size;
    sprite_dsc_.data = sprite_buf_;
}

void RobotEyes::BuildEyes(lv_obj_t* parent) {
    root_ = MakePlain(parent);
    lv_obj_set_size(root_, screen_w_, screen_h_);
    lv_obj_set_pos(root_, 0, 0);
    lv_obj_add_event_cb(root_, &RobotEyes::OnRootDeleted, LV_EVENT_DELETE, this);

    for (int i = 0; i < 2; ++i) {
        // Mata (sprite)
        img_[i] = lv_image_create(root_);
        lv_obj_remove_style_all(img_[i]);
        lv_image_set_src(img_[i], &sprite_dsc_);
        lv_image_set_pivot(img_[i], sprite_w_ / 2, sprite_h_ / 2);
        lv_obj_set_style_image_recolor_opa(img_[i], kRecolorOpa, 0);
        lv_obj_remove_flag(img_[i], LV_OBJ_FLAG_CLICKABLE);

        // Kilau
        hl_big_[i] = MakePill(root_, lv_color_white(), LV_OPA_80);
        hl_small_[i] = MakePill(root_, lv_color_white(), LV_OPA_50);

        // Kelopak: kotak transparan seukuran sprite, anak-anaknya dipotong di tepinya.
        lid_box_[i] = MakePlain(root_);
        lv_obj_set_size(lid_box_[i], sprite_w_, sprite_h_);

        lid_line_[i] = lv_line_create(lid_box_[i]);
        lv_obj_remove_style_all(lid_line_[i]);
        lv_obj_set_pos(lid_line_[i], -kLidOff, -kLidOff);
        lv_obj_set_style_line_width(lid_line_[i], kLidWidth, 0);
        lv_obj_set_style_line_color(lid_line_[i], bg_color_, 0);
        lv_obj_set_style_line_opa(lid_line_[i], LV_OPA_COVER, 0);
        lv_obj_set_style_line_rounded(lid_line_[i], false, 0);
        lv_obj_remove_flag(lid_line_[i], LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_flag(lid_line_[i], LV_OBJ_FLAG_HIDDEN);

        mask_[i] = MakePill(lid_box_[i], bg_color_, LV_OPA_COVER);
        lv_obj_add_flag(mask_[i], LV_OBJ_FLAG_HIDDEN);
    }
}

void RobotEyes::SetEmotion(const char* emotion) { mood_ = MoodFromName(emotion); }

void RobotEyes::TimerCb(lv_timer_t* timer) {
    static_cast<RobotEyes*>(lv_timer_get_user_data(timer))->Tick();
}

void RobotEyes::Tick() {
    if (root_ == nullptr) {
        return;
    }
    const uint32_t now = lv_tick_get();
    float dt = (now - last_tick_) / 1000.0f;
    last_tick_ = now;
    dt = Clampf(dt, 0.0f, 0.1f);

    const Look& look = LookFor(mood_);

    // Kedip otomatis
    float blink_mult = 1.0f;
    if (blink_start_ == 0 && now >= next_blink_) {
        blink_start_ = now;
        if (blink_start_ == 0) {
            blink_start_ = 1;
        }
    }
    if (blink_start_ != 0) {
        const float p = (now - blink_start_) / 180.0f;
        if (p >= 1.0f) {
            blink_start_ = 0;
            next_blink_ = now + RandRange(2800, 6500);
        } else {
            const float tri = p < 0.5f ? p * 2.0f : (1.0f - p) * 2.0f;
            blink_mult = 1.0f - 0.92f * tri;
        }
    }

    // Melirik acak
    if (now >= next_gaze_) {
        if (esp_random() % 100 < 40) {
            gaze_tx_ = 0;
            gaze_ty_ = 0;
        } else {
            gaze_tx_ = RandSigned() * 14.0f;
            gaze_ty_ = RandSigned() * 9.0f;
        }
        next_gaze_ = now + RandRange(2200, 5500);
    }

    const float k = 1.0f - expf(-dt * 14.0f);  // perpindahan halus
    const float kg = 1.0f - expf(-dt * 8.0f);
    gaze_x_ += (gaze_tx_ * look.gaze - gaze_x_) * kg;
    gaze_y_ += (gaze_ty_ * look.gaze - gaze_y_) * kg;

    cur_sx_ += (look.sx - cur_sx_) * k;
    cur_sy_ += (look.sy - cur_sy_) * k;
    cur_lo_ += (look.lid_out - cur_lo_) * k;
    cur_li_ += (look.lid_in - cur_li_) * k;
    cur_mask_ += (look.mask - cur_mask_) * k;
    cur_ox_ += (look.ox - cur_ox_) * k;
    cur_oy_ += (look.oy - cur_oy_) * k;

    const float tr = (look.color >> 16) & 0xFF;
    const float tg = (look.color >> 8) & 0xFF;
    const float tb = look.color & 0xFF;
    cur_r_ += (tr - cur_r_) * k;
    cur_g_ += (tg - cur_g_) * k;
    cur_b_ += (tb - cur_b_) * k;

    const float t = now / 1000.0f;
    const float shake_x = look.shake_x != 0.0f ? sinf(t * 2.0f * kPi * 5.0f) * look.shake_x : 0.0f;
    const float shake_y = look.shake_y != 0.0f ? sinf(t * 2.0f * kPi * 7.0f) * look.shake_y : 0.0f;

    const uint32_t color =
        (static_cast<uint32_t>(lroundf(Clampf(cur_r_, 0, 255))) << 16) |
        (static_cast<uint32_t>(lroundf(Clampf(cur_g_, 0, 255))) << 8) |
        static_cast<uint32_t>(lroundf(Clampf(cur_b_, 0, 255)));

    ApplyLook(cur_sx_, cur_sy_ * blink_mult, cur_ox_ + gaze_x_ + shake_x,
              cur_oy_ + gaze_y_ + shake_y, cur_lo_, cur_li_, cur_mask_, color);
}

void RobotEyes::ApplyLook(float sx, float sy, float ox, float oy, float lo, float li, float mask,
                          uint32_t color) {
    if (root_ == nullptr) {
        return;
    }
    const int sxi = std::max(12, static_cast<int>(256.0f * sx));
    const int syi = std::max(12, static_cast<int>(256.0f * sy));
    const int oxi = static_cast<int>(lroundf(ox));
    const int oyi = static_cast<int>(lroundf(oy));
    const int loi = static_cast<int>(lo * 100.0f);
    const int lii = static_cast<int>(li * 100.0f);
    const int mki = static_cast<int>(mask * 100.0f);

    if (applied_.valid && applied_.sxi == sxi && applied_.syi == syi && applied_.ox == oxi &&
        applied_.oy == oyi && applied_.lo == loi && applied_.li == lii && applied_.mk == mki &&
        applied_.color == color) {
        return;  // tidak ada perubahan terlihat
    }
    const bool color_changed = !applied_.valid || applied_.color != color;
    applied_.valid = true;
    applied_.sxi = sxi;
    applied_.syi = syi;
    applied_.ox = oxi;
    applied_.oy = oyi;
    applied_.lo = loi;
    applied_.li = lii;
    applied_.mk = mki;
    applied_.color = color;

    const float sxf = sxi / 256.0f;
    const float syf = syi / 256.0f;
    const float rx = static_cast<float>(rx_);
    const float ry = static_cast<float>(ry_);
    const float wc = static_cast<float>(sprite_w_);
    const float hc = static_cast<float>(sprite_h_);
    const lv_color_t recolor =
        lv_color_make((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF);

    for (int i = 0; i < 2; ++i) {
        const int ex = cx_[i] + oxi;
        const int ey = cy_ + oyi;
        const int left = ex - sprite_w_ / 2;
        const int top = ey - sprite_h_ / 2;

        lv_obj_set_pos(img_[i], left, top);
        lv_image_set_scale_x(img_[i], sxi);
        lv_image_set_scale_y(img_[i], syi);
        if (color_changed) {
            lv_obj_set_style_image_recolor(img_[i], recolor, 0);
        }

        // Kilau (hilang saat mata hampir tertutup)
        const bool show_hl = syf > 0.5f;
        if (show_hl) {
            const int bw = std::max(4, static_cast<int>(rx * 0.56f * sxf));
            const int bh = std::max(4, static_cast<int>(ry * 0.40f * syf));
            lv_obj_set_size(hl_big_[i], bw, bh);
            lv_obj_set_pos(hl_big_[i], static_cast<int>(ex - 0.35f * rx * sxf - bw / 2),
                           static_cast<int>(ey - 0.42f * ry * syf - bh / 2));
            const int sw = std::max(3, static_cast<int>(rx * 0.24f * sxf));
            const int sh = std::max(3, static_cast<int>(ry * 0.16f * syf));
            lv_obj_set_size(hl_small_[i], sw, sh);
            lv_obj_set_pos(hl_small_[i], static_cast<int>(ex + 0.35f * rx * sxf - sw / 2),
                           static_cast<int>(ey + 0.45f * ry * syf - sh / 2));
            lv_obj_remove_flag(hl_big_[i], LV_OBJ_FLAG_HIDDEN);
            lv_obj_remove_flag(hl_small_[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(hl_big_[i], LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(hl_small_[i], LV_OBJ_FLAG_HIDDEN);
        }

        // Kelopak
        lv_obj_set_pos(lid_box_[i], left, top);

        const float y0 = hc * 0.5f - ry * syf;  // tepi atas mata (koordinat lokal kotak)
        auto lid_y = [&](float amount) { return y0 - 4.0f + amount * (0.85f * ry * syf + 7.0f); };
        const float y_left = (i == 0) ? lid_y(lo) : lid_y(li);
        const float y_right = (i == 0) ? lid_y(li) : lid_y(lo);
        if (lo > 0.02f || li > 0.02f) {
            const float xa = -40.0f;
            const float xb = wc + 40.0f;
            const float slope = (y_right - y_left) / wc;
            const float ya = y_left + slope * xa;
            const float yb = y_left + slope * xb;
            const float dx = xb - xa;
            const float dy = yb - ya;
            const float len = sqrtf(dx * dx + dy * dy);
            const float ux = dy / len;   // normal ke atas
            const float uy = -dx / len;
            const float half = kLidWidth * 0.5f;
            lid_pts_[i][0].x = static_cast<lv_value_precise_t>(lroundf(xa + ux * half + kLidOff));
            lid_pts_[i][0].y = static_cast<lv_value_precise_t>(lroundf(ya + uy * half + kLidOff));
            lid_pts_[i][1].x = static_cast<lv_value_precise_t>(lroundf(xb + ux * half + kLidOff));
            lid_pts_[i][1].y = static_cast<lv_value_precise_t>(lroundf(yb + uy * half + kLidOff));
            lv_line_set_points(lid_line_[i], lid_pts_[i], 2);
            lv_obj_remove_flag(lid_line_[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(lid_line_[i], LV_OBJ_FLAG_HIDDEN);
        }

        // Lengkung "senang": oval hitam naik dari bawah menutup separuh bawah mata.
        if (mask > 0.02f) {
            const int mw = static_cast<int>(2.0f * rx * 1.45f * sxf);
            const int mh = std::max(4, static_cast<int>(2.0f * ry * 0.98f * syf));
            const float mcy = hc * 0.5f + ry * syf * 0.55f + (1.0f - mask) * ry * syf * 1.7f;
            lv_obj_set_size(mask_[i], mw, mh);
            lv_obj_set_pos(mask_[i], static_cast<int>(wc * 0.5f - mw * 0.5f),
                           static_cast<int>(mcy - mh * 0.5f));
            lv_obj_remove_flag(mask_[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(mask_[i], LV_OBJ_FLAG_HIDDEN);
        }
    }
}
