#ifndef _JOGET_H_
#define _JOGET_H_

#include <atomic>
#include <functional>

#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include "motor_controller.h"
#include "rgb_effects.h"

extern const unsigned char joget_ogg_data[];
extern const size_t joget_ogg_size;

// Rutin "joget": putar lagu, robot bergerak selama lagu, layar kembang api, lampu RGB.
// Setelah lagu selesai robot berteriak "HOBA" lalu kembali ke standby.
class Joget {
public:
    Joget(MotorController* motor, RgbEffects* rgb, std::function<void(bool)> set_display_dance,
          std::function<void(const char*)> set_emotion);

    // Dipanggil tool MCP "self.joget". Lagu dimulai setelah AI selesai menjawab (TTS stop).
    void Request();
    // Dipanggil saat TTS berhenti. true = joget dimulai (state tetap Speaking).
    bool OnTtsStopped();
    // Gerak wiggle singkat sebelum memutar lagu YouTube (blocking sekitar 1 detik).
    void Wiggle();
    // Hentikan joget (tombol BOOT).
    void Abort();
    bool IsActive() const { return active_.load(); }

private:
    static void TaskEntry(void* arg);
    static void AudioEntry(void* arg);
    static void FallbackCb(void* arg);
    void Start();
    void Run();
    void Finish(bool aborted);
    void DanceStep(int index);

    MotorController* motor_;
    RgbEffects* rgb_;
    std::function<void(bool)> set_display_dance_;
    std::function<void(const char*)> set_emotion_;

    std::atomic<bool> pending_{false};
    std::atomic<bool> active_{false};
    std::atomic<bool> abort_{false};
    std::atomic<bool> audio_done_{false};
    esp_timer_handle_t fallback_timer_ = nullptr;
};

#endif  // _JOGET_H_
