#ifndef _EYES_DISPLAY_H_
#define _EYES_DISPLAY_H_

#include <esp_log.h>

#include "display/lcd_display.h"
#include "robot_eyes.h"

// Layar ST7789 dengan tema 1 diganti tampilan mata robot (tanpa status bar dan teks).
// Tema 2 (chat) tidak diubah.
class EyesLcdDisplay : public SpiLcdDisplay {
public:
    using SpiLcdDisplay::SpiLcdDisplay;

    ~EyesLcdDisplay() {
        DisplayLockGuard lock(this);
        delete eyes_;
        eyes_ = nullptr;
    }

    void SetupUI() override {
        if (setup_ui_called_) {
            LcdDisplay::SetupUI();  // hanya mencatat peringatan "dipanggil ganda"
            return;
        }
        {
            DisplayLockGuard lock(this);
            delete eyes_;  // sisa tema sebelumnya (DestroyUI tidak menghapusnya)
            eyes_ = nullptr;
        }
        LcdDisplay::SetupUI();

        DisplayLockGuard lock(this);
        if (ui_theme_id_ != 1) {
            hide_subtitle_ = false;
            return;
        }
        eyes_ = new RobotEyes(lv_screen_active(), width_, height_, kEyesBg);
        if (eyes_->root() == nullptr) {
            ESP_LOGW("EyesDisplay", "Mata gagal dibuat, memakai tampilan standar");
            delete eyes_;
            eyes_ = nullptr;
            return;
        }
        HideStandardWidgets();
        hide_subtitle_ = true;
        if (emoji_box_ != nullptr) {
            lv_obj_move_to_index(eyes_->root(), lv_obj_get_index(emoji_box_));
        }
    }

    void SetTheme(Theme* theme) override {
        LcdDisplay::SetTheme(theme);
        if (eyes_ != nullptr && ui_theme_id_ == 1) {
            DisplayLockGuard lock(this);
            ApplyDarkBackground();
            HideStandardWidgets();
        }
    }

    void SetEmotion(const char* emotion) override {
        if (eyes_ != nullptr && ui_theme_id_ == 1) {
            if (music_visualizer_active_) {
                return;
            }
            DisplayLockGuard lock(this);
            eyes_->SetEmotion(emotion);
            return;
        }
        LcdDisplay::SetEmotion(emotion);
    }

    void SetPreviewImage(std::unique_ptr<LvglImage> image) override {
        LcdDisplay::SetPreviewImage(std::move(image));
        KeepEmojiHidden();  // akhir pratinjau kamera memunculkan kembali ikon robot
    }

    void StopMusicVisualizer() override {
        LcdDisplay::StopMusicVisualizer();
        KeepEmojiHidden();
    }

private:
    static constexpr uint32_t kEyesBgHex = 0x04050A;
    const lv_color_t kEyesBg = lv_color_hex(kEyesBgHex);
    RobotEyes* eyes_ = nullptr;

    void KeepEmojiHidden() {
        if (eyes_ != nullptr && ui_theme_id_ == 1 && emoji_box_ != nullptr) {
            DisplayLockGuard lock(this);
            lv_obj_add_flag(emoji_box_, LV_OBJ_FLAG_HIDDEN);
        }
    }

    void ApplyDarkBackground() {
        if (container_ != nullptr) {
            lv_obj_set_style_bg_image_src(container_, nullptr, 0);
            lv_obj_set_style_bg_opa(container_, LV_OPA_COVER, 0);
            lv_obj_set_style_bg_color(container_, kEyesBg, 0);
        }
        lv_obj_t* screen = lv_screen_active();
        lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
        lv_obj_set_style_bg_color(screen, kEyesBg, 0);
    }

    void HideStandardWidgets() {
        ApplyDarkBackground();
        if (top_bar_ != nullptr) lv_obj_add_flag(top_bar_, LV_OBJ_FLAG_HIDDEN);
        if (status_bar_ != nullptr) lv_obj_add_flag(status_bar_, LV_OBJ_FLAG_HIDDEN);
        if (bottom_bar_ != nullptr) lv_obj_add_flag(bottom_bar_, LV_OBJ_FLAG_HIDDEN);
        if (emoji_box_ != nullptr) lv_obj_add_flag(emoji_box_, LV_OBJ_FLAG_HIDDEN);
    }
};

#endif  // _EYES_DISPLAY_H_
