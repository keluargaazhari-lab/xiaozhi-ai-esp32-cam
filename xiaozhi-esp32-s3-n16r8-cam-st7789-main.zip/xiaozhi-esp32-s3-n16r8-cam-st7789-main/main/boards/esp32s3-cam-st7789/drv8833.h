#pragma once
// Driver motor DRV8833 (2 motor DC) via LEDC PWM + tool MCP.
// Pin diatur di config.h (DRV8833_AIN1_GPIO dst). Pakai LEDC timer 3, channel 4-7
// (kamera memakai timer 2/channel 2, backlight timer 0/channel 0).

#include <driver/gpio.h>
#include <driver/ledc.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <algorithm>
#include <cstdlib>
#include <string>

#include "mcp_server.h"

class Drv8833 {
public:
    static Drv8833& GetInstance() {
        static Drv8833 instance;
        return instance;
    }

    bool Init(gpio_num_t ain1, gpio_num_t ain2, gpio_num_t bin1, gpio_num_t bin2) {
        if (initialized_) {
            return true;
        }
        pins_[0] = ain1;
        pins_[1] = ain2;
        pins_[2] = bin1;
        pins_[3] = bin2;
        for (int i = 0; i < 4; i++) {
            if (pins_[i] == GPIO_NUM_NC) {
                ESP_LOGW(kTag, "Pin DRV8833 #%d belum diatur, driver tidak aktif", i);
                return false;
            }
        }

        ledc_timer_config_t timer = {};
        timer.speed_mode = LEDC_LOW_SPEED_MODE;
        timer.duty_resolution = LEDC_TIMER_8_BIT;
        timer.timer_num = LEDC_TIMER_3;
        timer.freq_hz = 20000;
        timer.clk_cfg = LEDC_AUTO_CLK;
        if (ledc_timer_config(&timer) != ESP_OK) {
            ESP_LOGE(kTag, "Gagal konfigurasi timer LEDC");
            return false;
        }

        for (int i = 0; i < 4; i++) {
            ledc_channel_config_t ch = {};
            ch.gpio_num = pins_[i];
            ch.speed_mode = LEDC_LOW_SPEED_MODE;
            ch.channel = (ledc_channel_t)(LEDC_CHANNEL_4 + i);
            ch.intr_type = LEDC_INTR_DISABLE;
            ch.timer_sel = LEDC_TIMER_3;
            ch.duty = 0;
            ch.hpoint = 0;
            if (ledc_channel_config(&ch) != ESP_OK) {
                ESP_LOGE(kTag, "Gagal konfigurasi channel LEDC %d", i);
                return false;
            }
        }
        initialized_ = true;
        Stop();
        ESP_LOGI(kTag, "DRV8833 siap: A=%d/%d B=%d/%d", (int)ain1, (int)ain2, (int)bin1, (int)bin2);
        return true;
    }

    // motor: 0 = A, 1 = B. speed: -100..100 (negatif = mundur)
    void SetMotor(int motor, int speed) {
        if (!initialized_ || motor < 0 || motor > 1) {
            return;
        }
        speed = std::max(-100, std::min(100, speed));
        uint32_t duty = (uint32_t)(std::abs(speed) * 255 / 100);
        int in1 = motor * 2;
        int in2 = motor * 2 + 1;
        if (speed > 0) {
            SetDuty(in1, duty);
            SetDuty(in2, 0);
        } else if (speed < 0) {
            SetDuty(in1, 0);
            SetDuty(in2, duty);
        } else {
            SetDuty(in1, 0);
            SetDuty(in2, 0);  // coast
        }
    }

    void Stop() {
        SetMotor(0, 0);
        SetMotor(1, 0);
    }

    void Brake() {
        if (!initialized_) {
            return;
        }
        for (int i = 0; i < 4; i++) {
            SetDuty(i, 255);
        }
    }

    // Gerak dengan dua motor sekaligus
    void Drive(int left, int right) {
        SetMotor(0, left);
        SetMotor(1, right);
    }

    bool IsInitialized() const { return initialized_; }

    // Daftarkan tool MCP supaya bisa dikendalikan lewat suara/AI.
    void RegisterTools() {
        auto& mcp = McpServer::GetInstance();

        mcp.AddTool(
            "self.motor.move",
            "Gerakkan robot dengan 2 motor DC (DRV8833). direction: forward, backward, left, right. "
            "speed 0-100. duration_ms 0 = jalan terus sampai dihentikan (self.motor.stop), "
            "isi 100-10000 untuk berhenti otomatis.",
            PropertyList({Property("direction", kPropertyTypeString, "forward"),
                          Property("speed", kPropertyTypeInteger, 70, 0, 100),
                          Property("duration_ms", kPropertyTypeInteger, 0, 0, 10000)}),
            [this](const PropertyList& properties) -> ReturnValue {
                std::string dir = properties["direction"].value<std::string>();
                int speed = properties["speed"].value<int>();
                int duration = properties["duration_ms"].value<int>();
                if (dir == "forward") {
                    Drive(speed, speed);
                } else if (dir == "backward") {
                    Drive(-speed, -speed);
                } else if (dir == "left") {
                    Drive(-speed, speed);
                } else if (dir == "right") {
                    Drive(speed, -speed);
                } else {
                    return false;
                }
                ScheduleStop(duration);
                return true;
            });

        mcp.AddTool("self.motor.set",
                    "Atur satu motor langsung. motor: 0 = A, 1 = B. speed -100..100 (negatif = mundur).",
                    PropertyList({Property("motor", kPropertyTypeInteger, 0, 0, 1),
                                  Property("speed", kPropertyTypeInteger, 0, -100, 100)}),
                    [this](const PropertyList& properties) -> ReturnValue {
                        SetMotor(properties["motor"].value<int>(), properties["speed"].value<int>());
                        return true;
                    });

        mcp.AddTool("self.motor.stop", "Hentikan semua motor", PropertyList(),
                    [this](const PropertyList& properties) -> ReturnValue {
                        CancelStopTimer();
                        Stop();
                        return true;
                    });
    }

private:
    Drv8833() = default;

    static constexpr const char* kTag = "DRV8833";

    void SetDuty(int index, uint32_t duty) {
        ledc_channel_t ch = (ledc_channel_t)(LEDC_CHANNEL_4 + index);
        ledc_set_duty(LEDC_LOW_SPEED_MODE, ch, duty);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, ch);
    }

    void CancelStopTimer() {
        if (stop_timer_ != nullptr) {
            esp_timer_stop(stop_timer_);
        }
    }

    void ScheduleStop(int duration_ms) {
        CancelStopTimer();
        if (duration_ms <= 0) {
            return;
        }
        if (stop_timer_ == nullptr) {
            esp_timer_create_args_t args = {};
            args.callback = [](void* arg) { static_cast<Drv8833*>(arg)->Stop(); };
            args.arg = this;
            args.dispatch_method = ESP_TIMER_TASK;
            args.name = "drv8833_stop";
            if (esp_timer_create(&args, &stop_timer_) != ESP_OK) {
                stop_timer_ = nullptr;
                return;
            }
        }
        esp_timer_start_once(stop_timer_, (uint64_t)duration_ms * 1000ULL);
    }

    bool initialized_ = false;
    gpio_num_t pins_[4] = {GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC};
    esp_timer_handle_t stop_timer_ = nullptr;
};
