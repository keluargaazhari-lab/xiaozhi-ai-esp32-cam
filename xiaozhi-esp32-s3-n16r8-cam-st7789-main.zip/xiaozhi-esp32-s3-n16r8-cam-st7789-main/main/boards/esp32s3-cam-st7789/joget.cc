#include "joget.h"

#include <string_view>
#include <utility>

#include <esp_log.h>
#include <esp_random.h>

#include "application.h"

#define TAG "Joget"

Joget::Joget(MotorController* motor, RgbEffects* rgb, std::function<void(bool)> set_display_dance,
             std::function<void(const char*)> set_emotion)
    : motor_(motor),
      rgb_(rgb),
      set_display_dance_(std::move(set_display_dance)),
      set_emotion_(std::move(set_emotion)) {
    esp_timer_create_args_t args = {};
    args.callback = &Joget::FallbackCb;
    args.arg = this;
    args.name = "joget_fallback";
    args.dispatch_method = ESP_TIMER_TASK;
    esp_timer_create(&args, &fallback_timer_);
}

void Joget::Request() {
    if (active_.load()) {
        return;
    }
    pending_.store(true);
    // Cadangan: kalau AI tidak mengucapkan apa pun, mulai joget setelah 6 detik.
    if (fallback_timer_ != nullptr) {
        esp_timer_stop(fallback_timer_);
        esp_timer_start_once(fallback_timer_, 6ULL * 1000 * 1000);
    }
    ESP_LOGI(TAG, "Joget diminta, menunggu AI selesai bicara");
}

void Joget::FallbackCb(void* arg) {
    auto* self = static_cast<Joget*>(arg);
    Application::GetInstance().Schedule([self]() {
        if (self->pending_.exchange(false)) {
            self->Start();
        }
    });
}

bool Joget::OnTtsStopped() {
    if (!pending_.exchange(false)) {
        return false;
    }
    if (fallback_timer_ != nullptr) {
        esp_timer_stop(fallback_timer_);
    }
    Start();
    return true;
}

void Joget::Start() {
    if (active_.exchange(true)) {
        return;
    }
    ESP_LOGI(TAG, "Mulai joget!");
    abort_.store(false);
    audio_done_.store(false);

    auto& app = Application::GetInstance();
    app.SetDeviceState(kDeviceStateSpeaking);  // mic dimatikan selama lagu
    if (set_display_dance_) set_display_dance_(true);
    if (rgb_) rgb_->StartDance();

    xTaskCreate(&Joget::TaskEntry, "joget", 4096, this, 4, nullptr);
}

void Joget::TaskEntry(void* arg) {
    static_cast<Joget*>(arg)->Run();
    vTaskDelete(nullptr);
}

void Joget::AudioEntry(void* arg) {
    auto* self = static_cast<Joget*>(arg);
    vTaskDelay(pdMS_TO_TICKS(400));  // beri waktu perubahan state (reset decoder) selesai dulu
    auto& audio = Application::GetInstance().GetAudioService();
    audio.PlayLongSound(
        std::string_view(reinterpret_cast<const char*>(joget_ogg_data), joget_ogg_size),
        &self->abort_);
    self->audio_done_.store(true);
    vTaskDelete(nullptr);
}

void Joget::DanceStep(int index) {
    if (motor_ == nullptr) {
        vTaskDelay(pdMS_TO_TICKS(400));
        return;
    }
    // Pola joget: maju-mundur, putar kiri-kanan, goyang. Selalu 100% tenaga.
    struct Move { int l, r; uint32_t ms; };
    static const Move kMoves[] = {
        {100, 100, 320},   // maju
        {-100, -100, 320}, // mundur
        {-100, 100, 280},  // putar kiri
        {100, -100, 280},  // putar kanan
        {100, 100, 220},   // maju pendek
        {-100, 100, 220},  // goyang kiri
        {100, -100, 220},  // goyang kanan
        {-100, -100, 220}, // mundur pendek
        {-100, 100, 450},  // putar kiri panjang
        {100, -100, 450},  // putar kanan panjang
    };
    const int n = sizeof(kMoves) / sizeof(kMoves[0]);
    int pick = (index % 2 == 0) ? (esp_random() % n) : ((index / 2) % 4 + 2);  // selang-seling acak/teratur
    const Move& m = kMoves[pick % n];
    motor_->Drive(m.l, m.r, m.ms);
    vTaskDelay(pdMS_TO_TICKS(m.ms + 160));
}

void Joget::Run() {
    xTaskCreate(&Joget::AudioEntry, "joget_audio", 6144, this, 3, nullptr);

    auto& audio = Application::GetInstance().GetAudioService();
    const int64_t start_us = esp_timer_get_time();
    int step = 0;
    int idle_checks = 0;
    while (!abort_.load()) {
        if (audio_done_.load()) {
            // lagu sudah dikirim semua; tunggu sampai habis diputar
            if (audio.IsPlaybackIdle()) {
                if (++idle_checks >= 3) break;
            } else {
                idle_checks = 0;
            }
        }
        if ((esp_timer_get_time() - start_us) > 90LL * 1000 * 1000) {
            ESP_LOGW(TAG, "Joget melebihi 90 detik, dihentikan");
            break;
        }
        DanceStep(step++);
    }
    const bool aborted = abort_.load();
    if (motor_) motor_->Stop();
    Application::GetInstance().Schedule([this, aborted]() { Finish(aborted); });
}

void Joget::Finish(bool aborted) {
    ESP_LOGI(TAG, "Joget selesai%s", aborted ? " (dihentikan)" : "");
    if (motor_) motor_->Stop();
    if (set_display_dance_) set_display_dance_(false);
    if (rgb_) rgb_->Stop();
    active_.store(false);

    auto& app = Application::GetInstance();
    app.GetAudioService().ResetDecoder();
    if (app.GetDeviceState() != kDeviceStateIdle) {
        app.SetDeviceState(kDeviceStateIdle);
    }
    // Selesai joget: langsung standby, tanpa mengirim teks apa pun ke server.
    // (Dulu mengirim "Hoba" lewat pesan detect; server menganggapnya ucapan pengguna dan
    // AI memanggil joget lagi, jadi joget berulang tanpa henti.)
    (void)aborted;
}

void Joget::Abort() {
    if (!active_.load()) {
        return;
    }
    abort_.store(true);
    Application::GetInstance().GetAudioService().ResetDecoder();
}

void Joget::Wiggle() {
    if (motor_ != nullptr) {
        // goyang cepat kiri-kanan sebelum lagu diputar
        static const int kDir[] = {-1, 1, -1, 1};
        for (int d : kDir) {
            motor_->Drive(100 * d, -100 * d, 200);
            vTaskDelay(pdMS_TO_TICKS(330));
        }
        motor_->Stop();
    }
    if (rgb_) rgb_->StartFlash(1800);
    if (set_emotion_) set_emotion_("happy");
}
