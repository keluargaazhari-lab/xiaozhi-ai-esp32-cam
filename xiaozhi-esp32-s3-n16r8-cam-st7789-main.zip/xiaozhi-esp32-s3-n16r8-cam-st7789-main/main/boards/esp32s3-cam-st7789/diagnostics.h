#ifndef _DIAGNOSTICS_H_
#define _DIAGNOSTICS_H_

// Diagnostik serial: mencetak penyebab reset, sisa reset sebelumnya (RTC),
// ringkasan kesehatan berkala (heap, state), dan jejak (backtrace) saat esp_restart().
// Semua baris diberi awalan [DIAG] supaya mudah dicari di log.
class Diagnostics {
public:
    // Panggil sedini mungkin di konstruktor board.
    static void Init();
};

#endif  // _DIAGNOSTICS_H_
