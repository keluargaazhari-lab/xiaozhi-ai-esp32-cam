#ifndef _ROBOT_EYES_H_
#define _ROBOT_EYES_H_

#include <cstdint>

#include <lvgl.h>

// Mata gaya "glowstick" (hijau kuning terang, pupil celah, pipi merona) untuk layar LVGL.
// - Bentuk mata asli (hampir bulat), ekspresi lewat kelopak hitam dan lengkung bawah.
// - Berkedip otomatis, melirik acak, perpindahan antar-ekspresi halus.
// - Mode joget: mata mengecil di bawah, kembang api meledak, pupil mengikuti ledakan.
// Semua operasi LVGL harus dipanggil dengan lock display.
class RobotEyes {
public:
    RobotEyes(lv_obj_t* parent, int screen_w, int screen_h, lv_color_t bg_color);
    ~RobotEyes();

    // Terima nama emosi XiaoZhi (neutral, happy, sad, angry, ...). Diabaikan saat joget.
    void SetEmotion(const char* emotion);
    // Mode joget (kembang api + mata kecil yang melihat ledakan).
    void SetDance(bool on);
    lv_obj_t* root() const { return root_; }

private:
    enum Mood {
        kIdle,
        kHappy,
        kSleepy,
        kCurious,
        kSurprised,
        kLove,
        kDizzy,
        kAnnoyed,
        kSad,
        kExcited,
        kThinking,
    };

    struct Look {
        float sx, sy;       // skala lebar/tinggi mata
        float top, ang, curve;  // kelopak atas (0..1), kemiringan, lengkung
        float bot;          // kelopak bawah / lengkung senang (0..1)
        float pupil;        // skala pupil (kecil = celah menyempit)
        float lx, ly;       // arah pandang (-1..1)
        float oy;           // geser vertikal (piksel, skala layar 320)
        float blush;        // pipi merona (0..1)
        float gaze;         // seberapa jauh boleh melirik acak (0..1)
        float wobble;       // getar horizontal (piksel)
    };

    struct Applied {
        bool valid = false;
        int v[128] = {};
    };

    struct Particle {
        lv_obj_t* obj = nullptr;
        float x = 0, y = 0, vx = 0, vy = 0, life = 0, max_life = 1;
        int size = 0;
        bool active = false;
    };

    struct Rocket {
        lv_obj_t* obj = nullptr;
        float x0 = 0, y0 = 0, tx = 0, ty = 0, t = 0, dur = 1;
        uint32_t color = 0;
        bool active = false;
    };

    static Mood MoodFromName(const char* name);
    static const Look& LookFor(Mood mood);
    static void TimerCb(lv_timer_t* timer);
    static void OnRootDeleted(lv_event_t* e);

    void Build(lv_obj_t* parent);
    void Tick();
    void Apply(float sx_both, float sy_both, float dance_k, uint32_t now);
    void LaunchRocket(uint32_t now);
    void Burst(float x, float y, uint32_t color);
    void UpdateFireworks(float dt, uint32_t now);
    void SetFireworksVisible(bool visible);

    lv_color_t bg_color_;
    int screen_w_;
    int screen_h_;
    float s_ = 1.0f;          // skala dari layar referensi 320 px
    float A_ = 0, B_ = 0;     // jari-jari mata (px)
    int box_w_ = 0, box_h_ = 0;
    float cx_[2] = {0, 0};
    float cy_ = 0;

    lv_obj_t* root_ = nullptr;
    lv_timer_t* timer_ = nullptr;
    lv_obj_t* box_[2] = {nullptr, nullptr};
    lv_obj_t* sclera_[2] = {nullptr, nullptr};
    lv_obj_t* pupil_[2] = {nullptr, nullptr};
    lv_obj_t* lid_line_[2] = {nullptr, nullptr};
    lv_obj_t* mask_[2] = {nullptr, nullptr};
    lv_obj_t* blush_[2] = {nullptr, nullptr};
    lv_point_precise_t lid_pts_[2][2] = {};

    static constexpr int kParticles = 64;
    static constexpr int kRockets = 3;
    Particle particles_[kParticles];
    Rocket rockets_[kRockets];

    Mood mood_ = kIdle;
    Applied applied_;

    // keadaan saat ini (diperhalus menuju target)
    float cur_[16] = {};  // 0 sx,1 sy,2 top,3 ang,4 curve,5 bot,6 pupil,7 lx,8 ly,9 oy,10 blush,11 wobble
    float gaze_x_ = 0, gaze_y_ = 0, gaze_tx_ = 0, gaze_ty_ = 0;
    float dance_k_ = 0;
    bool dance_ = false;

    uint32_t last_tick_ = 0;
    uint32_t next_blink_ = 0;
    uint32_t blink_start_ = 0;
    uint32_t next_gaze_ = 0;
    uint32_t next_launch_ = 0;
    uint32_t surprise_until_ = 0;
    float focus_x_ = 0, focus_y_ = 0;
    uint32_t focus_until_ = 0;
    float flash_ = 0;
    uint32_t flash_color_ = 0;
    float swirl_ = 0;
};

#endif  // _ROBOT_EYES_H_
