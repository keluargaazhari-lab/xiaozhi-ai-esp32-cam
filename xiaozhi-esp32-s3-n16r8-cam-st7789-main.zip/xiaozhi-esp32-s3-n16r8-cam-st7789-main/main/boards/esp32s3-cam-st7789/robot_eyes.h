#ifndef _ROBOT_EYES_H_
#define _ROBOT_EYES_H_

#include <cstdint>

#include <lvgl.h>

// Mata robot oval vertikal berwarna (terinspirasi FluxGarage RoboEyes).
// - Dua mata oval dengan gradasi warna, cahaya, dan kilau.
// - Ekspresi (netral, senang, marah, ngantuk, dll.) lewat kelopak hitam dan warna.
// - Berkedip otomatis, melirik acak, perpindahan antar-ekspresi halus.
// Semua operasi LVGL harus dipanggil dengan lock display.
class RobotEyes {
public:
    RobotEyes(lv_obj_t* parent, int screen_w, int screen_h, lv_color_t bg_color);
    ~RobotEyes();

    // Terima nama emosi XiaoZhi (neutral, happy, sad, angry, ...).
    void SetEmotion(const char* emotion);
    lv_obj_t* root() const { return root_; }

private:
    enum Mood {
        kNeutral,
        kHappy,
        kLove,
        kLaugh,
        kSad,
        kAngry,
        kSurprised,
        kThinking,
        kSleepy,
        kConfused,
    };

    struct Look {
        float sx, sy;          // skala lebar/tinggi mata
        float lid_out;         // kelopak turun di sudut luar (0..1)
        float lid_in;          // kelopak turun di sudut dalam (0..1)
        float mask;            // lengkung "senang" (0..1)
        float ox, oy;          // geser dasar (piksel)
        float gaze;            // seberapa jauh boleh melirik acak (0..1)
        float shake_x, shake_y;  // getar (piksel)
        uint32_t color;        // warna 0xRRGGBB
    };

    struct Applied {
        bool valid = false;
        int sxi = 0, syi = 0, ox = 0, oy = 0, lo = 0, li = 0, mk = 0;
        uint32_t color = 0;
    };

    static Mood MoodFromName(const char* name);
    static const Look& LookFor(Mood mood);
    static void TimerCb(lv_timer_t* timer);
    static void OnRootDeleted(lv_event_t* e);

    void BuildSprite();
    void BuildEyes(lv_obj_t* parent);
    void Tick();
    void ApplyLook(float sx, float sy, float ox, float oy, float lo, float li, float mask,
                   uint32_t color);

    lv_color_t bg_color_;
    int screen_w_;
    int screen_h_;
    int rx_ = 0, ry_ = 0;
    int sprite_w_ = 0, sprite_h_ = 0;
    int cx_[2] = {0, 0};
    int cy_ = 0;

    uint8_t* sprite_buf_ = nullptr;
    lv_image_dsc_t sprite_dsc_ = {};

    lv_obj_t* root_ = nullptr;
    lv_timer_t* timer_ = nullptr;
    lv_obj_t* img_[2] = {nullptr, nullptr};
    lv_obj_t* hl_big_[2] = {nullptr, nullptr};
    lv_obj_t* hl_small_[2] = {nullptr, nullptr};
    lv_obj_t* lid_box_[2] = {nullptr, nullptr};
    lv_obj_t* lid_line_[2] = {nullptr, nullptr};
    lv_obj_t* mask_[2] = {nullptr, nullptr};
    lv_point_precise_t lid_pts_[2][2] = {};

    Mood mood_ = kNeutral;
    Applied applied_;

    // keadaan saat ini (diperhalus menuju target)
    float cur_sx_ = 1, cur_sy_ = 1, cur_lo_ = 0, cur_li_ = 0, cur_mask_ = 0, cur_ox_ = 0,
          cur_oy_ = 0;
    float cur_r_ = 0, cur_g_ = 0, cur_b_ = 0;
    float gaze_x_ = 0, gaze_y_ = 0, gaze_tx_ = 0, gaze_ty_ = 0;

    uint32_t last_tick_ = 0;
    uint32_t next_blink_ = 0;
    uint32_t blink_start_ = 0;
    uint32_t next_gaze_ = 0;
};

#endif  // _ROBOT_EYES_H_
