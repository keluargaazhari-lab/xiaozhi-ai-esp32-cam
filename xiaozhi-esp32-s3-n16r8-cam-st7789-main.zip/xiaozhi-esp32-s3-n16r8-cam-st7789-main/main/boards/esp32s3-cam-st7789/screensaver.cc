#include "screensaver.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

#include <esp_log.h>
#include <esp_timer.h>

#include "application.h"

LV_FONT_DECLARE(BUILTIN_TEXT_FONT);

#define TAG "Screensaver"

namespace {
constexpr uint32_t kTickMs = 200;
constexpr float kPi = 3.14159265f;

constexpr uint32_t kColorBezel = 0xF4F4F4;
constexpr uint32_t kColorFace = 0x2B2B2B;
constexpr uint32_t kColorNumber = 0xE8E8E8;
constexpr uint32_t kColorHour = 0xFFC107;
constexpr uint32_t kColorMinute = 0x1E9BFF;
constexpr uint32_t kColorSecond = 0xE53935;
constexpr uint32_t kColorCap = 0x4A4A4A;
constexpr uint32_t kColorDate = 0xD0D0D0;

const char* const kDays[] = {"Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"};
const char* const kMonths[] = {"Januari", "Februari", "Maret",     "April",   "Mei",      "Juni",
                               "Juli",    "Agustus",  "September", "Oktober", "November", "Desember"};

lv_obj_t* MakeCircle(lv_obj_t* parent, int diameter, uint32_t color) {
    lv_obj_t* obj = lv_obj_create(parent);
    lv_obj_set_size(obj, diameter, diameter);
    lv_obj_set_style_radius(obj, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(obj, lv_color_hex(color), 0);
    lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(obj, 0, 0);
    lv_obj_set_style_pad_all(obj, 0, 0);
    lv_obj_set_style_shadow_width(obj, 0, 0);
    lv_obj_remove_flag(obj, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_remove_flag(obj, LV_OBJ_FLAG_CLICKABLE);
    return obj;
}

lv_obj_t* MakeHand(lv_obj_t* parent, int width, uint32_t color) {
    lv_obj_t* line = lv_line_create(parent);
    lv_obj_set_pos(line, 0, 0);
    lv_obj_set_style_line_width(line, width, 0);
    lv_obj_set_style_line_color(line, lv_color_hex(color), 0);
    lv_obj_set_style_line_rounded(line, true, 0);
    lv_obj_set_style_pad_all(line, 0, 0);
    lv_obj_set_style_border_width(line, 0, 0);
    lv_obj_set_style_bg_opa(line, LV_OPA_TRANSP, 0);
    lv_obj_remove_flag(line, LV_OBJ_FLAG_CLICKABLE);
    return line;
}
}  // namespace

Screensaver::Screensaver(Display* display, std::function<bool()> is_busy, int idle_seconds)
    : display_(display),
      is_busy_(std::move(is_busy)),
      idle_us_(static_cast<int64_t>(idle_seconds) * 1000000LL) {
    idle_since_us_ = esp_timer_get_time();
    DisplayLockGuard lock(display_);
    timer_ = lv_timer_create(&Screensaver::TimerCb, kTickMs, this);
    ESP_LOGI(TAG, "Screensaver aktif: muncul setelah %d detik idle", idle_seconds);
}

void Screensaver::Wake() { wake_requested_.store(true); }

bool Screensaver::WakeIfShown() {
    const bool was_shown = shown_.load();
    wake_requested_.store(true);
    return was_shown;
}

void Screensaver::TimerCb(lv_timer_t* timer) {
    static_cast<Screensaver*>(lv_timer_get_user_data(timer))->Tick();
}

bool Screensaver::TimeValid(struct tm* out) {
    time_t now = time(nullptr);
    struct tm tm_now = {};
    localtime_r(&now, &tm_now);
    if (out != nullptr) {
        *out = tm_now;
    }
    return tm_now.tm_year >= (2024 - 1900);
}

void Screensaver::Tick() {
    const int64_t now_us = esp_timer_get_time();

    bool busy = Application::GetInstance().GetDeviceState() != kDeviceStateIdle;
    if (!busy && is_busy_) {
        busy = is_busy_();
    }
    if (wake_requested_.exchange(false)) {
        busy = true;
    }

    if (busy) {
        idle_since_us_ = now_us;
        if (shown_.load()) {
            Hide();
        }
        return;
    }

    if (!shown_.load()) {
        if (now_us - idle_since_us_ >= idle_us_ && TimeValid(nullptr)) {
            Show();
        }
        return;
    }
    UpdateClock(false);
}

void Screensaver::Show() {
    lv_display_t* disp = lv_display_get_default();
    const int w = lv_display_get_horizontal_resolution(disp);
    const int h = lv_display_get_vertical_resolution(disp);

    const int diameter = std::min(w - 8, h - 44);
    int top = (h - 36 - diameter) / 2;
    if (top < 2) {
        top = 2;
    }
    cx_ = w / 2;
    cy_ = top + diameter / 2;
    const int face_d = diameter - 8;
    radius_ = face_d / 2;

    root_ = lv_obj_create(lv_layer_top());
    lv_obj_set_size(root_, w, h);
    lv_obj_set_pos(root_, 0, 0);
    lv_obj_set_style_radius(root_, 0, 0);
    lv_obj_set_style_bg_color(root_, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(root_, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(root_, 0, 0);
    lv_obj_set_style_pad_all(root_, 0, 0);
    lv_obj_set_scrollbar_mode(root_, LV_SCROLLBAR_MODE_OFF);
    lv_obj_remove_flag(root_, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_remove_flag(root_, LV_OBJ_FLAG_CLICKABLE);

    lv_obj_t* bezel = MakeCircle(root_, diameter, kColorBezel);
    lv_obj_set_pos(bezel, cx_ - diameter / 2, top);
    lv_obj_t* face = MakeCircle(bezel, face_d, kColorFace);
    lv_obj_center(face);

    const float num_radius = radius_ * 0.78f;
    for (int n = 1; n <= 12; ++n) {
        const float a = n * 30.0f * kPi / 180.0f;
        lv_obj_t* label = lv_label_create(face);
        char text[4];
        snprintf(text, sizeof(text), "%d", n);
        lv_label_set_text(label, text);
        lv_obj_set_style_text_color(label, lv_color_hex(kColorNumber), 0);
        lv_obj_set_style_text_font(label, &BUILTIN_TEXT_FONT, 0);
        lv_obj_align(label, LV_ALIGN_CENTER, static_cast<int>(lroundf(num_radius * sinf(a))),
                     -static_cast<int>(lroundf(num_radius * cosf(a))));
    }

    hour_hand_ = MakeHand(root_, 8, kColorHour);
    minute_hand_ = MakeHand(root_, 5, kColorMinute);
    second_hand_ = MakeHand(root_, 2, kColorSecond);

    lv_obj_t* cap = MakeCircle(root_, 16, kColorCap);
    lv_obj_set_pos(cap, cx_ - 8, cy_ - 8);

    date_label_ = lv_label_create(root_);
    lv_obj_set_style_text_color(date_label_, lv_color_hex(kColorDate), 0);
    lv_obj_set_style_text_font(date_label_, &BUILTIN_TEXT_FONT, 0);
    lv_label_set_text(date_label_, "");
    date_y_ = top + diameter + (h - top - diameter - 18) / 2;
    lv_obj_align(date_label_, LV_ALIGN_TOP_MID, 0, date_y_);

    last_sec_ = -1;
    last_yday_ = -1;
    shown_.store(true);
    UpdateClock(true);
    ESP_LOGI(TAG, "Screensaver tampil");
}

void Screensaver::Hide() {
    if (root_ != nullptr) {
        lv_obj_delete(root_);
    }
    root_ = nullptr;
    hour_hand_ = nullptr;
    minute_hand_ = nullptr;
    second_hand_ = nullptr;
    date_label_ = nullptr;
    shown_.store(false);
    ESP_LOGI(TAG, "Screensaver disembunyikan");
}

void Screensaver::UpdateClock(bool force) {
    if (root_ == nullptr) {
        return;
    }
    struct tm t = {};
    TimeValid(&t);
    if (!force && t.tm_sec == last_sec_) {
        return;
    }
    last_sec_ = t.tm_sec;

    const float sec_deg = t.tm_sec * 6.0f;
    const float min_deg = t.tm_min * 6.0f + t.tm_sec * 0.1f;
    const float hour_deg = ((t.tm_hour % 12) * 60 + t.tm_min) * 0.5f;

    auto set_hand = [this](lv_obj_t* line, lv_point_precise_t* pts, float deg, float length,
                           float tail) {
        const float a = deg * kPi / 180.0f;
        pts[0].x = static_cast<lv_value_precise_t>(lroundf(cx_ - tail * sinf(a)));
        pts[0].y = static_cast<lv_value_precise_t>(lroundf(cy_ + tail * cosf(a)));
        pts[1].x = static_cast<lv_value_precise_t>(lroundf(cx_ + length * sinf(a)));
        pts[1].y = static_cast<lv_value_precise_t>(lroundf(cy_ - length * cosf(a)));
        lv_line_set_points(line, pts, 2);
    };
    set_hand(hour_hand_, hour_pts_, hour_deg, radius_ * 0.50f, 0.0f);
    set_hand(minute_hand_, minute_pts_, min_deg, radius_ * 0.74f, 0.0f);
    set_hand(second_hand_, second_pts_, sec_deg, radius_ * 0.86f, radius_ * 0.18f);

    if (force || t.tm_yday != last_yday_) {
        last_yday_ = t.tm_yday;
        char text[48];
        snprintf(text, sizeof(text), "%s, %d %s", kDays[t.tm_wday % 7], t.tm_mday,
                 kMonths[t.tm_mon % 12]);
        lv_label_set_text(date_label_, text);
        lv_obj_align(date_label_, LV_ALIGN_TOP_MID, 0, date_y_);
    }
}
