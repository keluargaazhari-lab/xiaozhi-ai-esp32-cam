#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

// =============================================================
// ESP32-S3 N16R8 CAM + ST7789 240x240 (7-Pin SPI) Board Config
// =============================================================

// ---- Audio (I2S Simplex - no codec IC: MAX98357A / WeAct PCM5100A / PCM5102A) ----
// 1 = mic & speaker berbagi pin clock BCLK/SCK (GPIO 40) dan WS/LRC (GPIO 41), mode duplex.
//     Kabel SCK dan WS mic (INMP441) disambung ke GPIO 40 dan 41. Pin L/R mic harus ke GND.
//     GPIO 1 dan 2 jadi kosong (dipakai motor kanan), sehingga TX/RX bebas untuk serial/log.
// 0 = mode terpisah seperti semula (mic SCK=2, WS=1).
#define AUDIO_SHARED_CLOCK 1
#if AUDIO_SHARED_CLOCK
#define AUDIO_INPUT_SAMPLE_RATE  24000  // mode duplex memakai satu clock untuk mic dan speaker
#else
#define AUDIO_INPUT_SAMPLE_RATE  16000
#endif
#define AUDIO_OUTPUT_SAMPLE_RATE 24000
#define AUDIO_I2S_METHOD_SIMPLEX

#if AUDIO_SHARED_CLOCK
#define AUDIO_I2S_MIC_GPIO_WS   GPIO_NUM_41
#define AUDIO_I2S_MIC_GPIO_SCK  GPIO_NUM_40
#else
#define AUDIO_I2S_MIC_GPIO_WS   GPIO_NUM_1
#define AUDIO_I2S_MIC_GPIO_SCK  GPIO_NUM_2
#endif
#define AUDIO_I2S_MIC_GPIO_DIN  GPIO_NUM_42
#define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_39
#define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_40
#define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_41
#define AUDIO_I2S_GPIO_MCLK     GPIO_NUM_NC

// ---- Buttons ----
#define BOOT_BUTTON_GPIO        GPIO_NUM_0
#define TOUCH_BUTTON_GPIO       GPIO_NUM_NC
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_14
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_46
#define WAKE_UP_BUTTON_GPIO     GPIO_NUM_NC
#define ACTION_BUTTON_GPIO      GPIO_NUM_NC

// ---- Battery ADC (100K voltage divider) ----
#define BATTERY_ADC_GPIO        GPIO_NUM_3
#define BATTERY_ADC_CHANNEL     ADC_CHANNEL_2
#define BATTERY_VOLTAGE_DIVIDER_RATIO 2.0  // 100K + 100K = 1:1 ratio
#define BATTERY_FULL_VOLTAGE    4200  // mV
#define BATTERY_EMPTY_VOLTAGE   3300  // mV

// ---- LED & Haptic Motor ----
#define BUILTIN_LED_GPIO        GPIO_NUM_48
#ifndef VIBRATION_MOTOR_PIN
#define VIBRATION_MOTOR_PIN     GPIO_NUM_NC  // Set pin motor getar jika terpasang (jangan gunakan GPIO 45 karena dipakai LCD CS)
#endif

// ---- Camera (OV2640 - standard ESP32-S3 CAM wiring) ----
#define CAMERA_PIN_D0     GPIO_NUM_11
#define CAMERA_PIN_D1     GPIO_NUM_9
#define CAMERA_PIN_D2     GPIO_NUM_8
#define CAMERA_PIN_D3     GPIO_NUM_10
#define CAMERA_PIN_D4     GPIO_NUM_12
#define CAMERA_PIN_D5     GPIO_NUM_18
#define CAMERA_PIN_D6     GPIO_NUM_17
#define CAMERA_PIN_D7     GPIO_NUM_16
#define CAMERA_PIN_XCLK   GPIO_NUM_15
#define CAMERA_PIN_PCLK   GPIO_NUM_13
#define CAMERA_PIN_VSYNC  GPIO_NUM_6
#define CAMERA_PIN_HREF   GPIO_NUM_7
#define CAMERA_PIN_SIOC   GPIO_NUM_5
#define CAMERA_PIN_SIOD   GPIO_NUM_4
#define CAMERA_PIN_PWDN   GPIO_NUM_NC
#define CAMERA_PIN_RESET  GPIO_NUM_NC
#define XCLK_FREQ_HZ      10000000  // 10MHz for GC2145 stability

// ---- Display ST7789 Configuration ----
//   Default: ST7789 240x280 (8-Pin SPI, CS GPIO 45)
#define DISPLAY_BACKLIGHT_PIN GPIO_NUM_38
#define DISPLAY_MOSI_PIN      GPIO_NUM_20
#define DISPLAY_CLK_PIN       GPIO_NUM_19
#define DISPLAY_DC_PIN        GPIO_NUM_47
#define DISPLAY_RST_PIN       GPIO_NUM_21
#define DISPLAY_CS_PIN        GPIO_NUM_45

#define LCD_TYPE_ST7789_SERIAL
#define DISPLAY_WIDTH   240
#define DISPLAY_HEIGHT  280
#define DISPLAY_MIRROR_X false
#define DISPLAY_MIRROR_Y false
#define DISPLAY_SWAP_XY  false
#define DISPLAY_INVERT_COLOR    true
#define DISPLAY_RGB_ORDER  LCD_RGB_ELEMENT_ORDER_RGB
#define DISPLAY_OFFSET_X  0
#define DISPLAY_OFFSET_Y  20
#define DISPLAY_BACKLIGHT_OUTPUT_INVERT false
#define DISPLAY_SPI_MODE 0

#endif // _BOARD_CONFIG_H_

// ---- Driver motor DRV8833 (2 motor DC) ----
// 1 = aktif. Pin dipinjam dari fungsi lain, jadi saat aktif:
//   GPIO 14 & 46 (tombol Volume +/-) dimatikan.
//   Motor kanan: kalau AUDIO_SHARED_CLOCK=1 memakai GPIO 1 & 2 (bekas pin clock mic), jadi
//   serial TX/RX tetap tersedia. Kalau 0, memakai GPIO 44/43 (RX/TX) dan serial tidak tersedia.
//   LED RGB (GPIO 48) dan baca baterai (GPIO 3) tetap seperti semula.
// Set 0 untuk mengembalikan semuanya seperti semula.
#define ENABLE_MOTOR 1
#if ENABLE_MOTOR
#define MOTOR_LEFT_IN1_GPIO     GPIO_NUM_14  // motor kiri (DRV8833 AIN1)
#define MOTOR_LEFT_IN2_GPIO     GPIO_NUM_46  // motor kiri (AIN2)
#if AUDIO_SHARED_CLOCK
#define MOTOR_RIGHT_IN1_GPIO    GPIO_NUM_1   // motor kanan (BIN1)
#define MOTOR_RIGHT_IN2_GPIO    GPIO_NUM_2   // motor kanan (BIN2)
#else
#define MOTOR_RIGHT_IN1_GPIO    GPIO_NUM_44  // motor kanan (BIN1) = pin RX0
#define MOTOR_RIGHT_IN2_GPIO    GPIO_NUM_43  // motor kanan (BIN2) = pin TX0
#endif
#undef VOLUME_UP_BUTTON_GPIO
#undef VOLUME_DOWN_BUTTON_GPIO
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_NC
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_NC
#endif

// Parameter kontrol motor
#define MOTOR_PWM_FREQUENCY_HZ          20000
#define MOTOR_MIN_DUTY_PERCENT          100   // perintah gerak selalu jalan 100% power
#define MOTOR_MAX_DUTY_PERCENT          100
#define MOTOR_MAX_RUN_TIME_MS           3000  // batas aman lama gerak
#define MOTOR_LEFT_INVERT               0     // ubah ke 1 kalau arah motor kiri terbalik
#define MOTOR_RIGHT_INVERT              0     // ubah ke 1 kalau arah motor kanan terbalik
#define MOTOR_DIRECTION_DEAD_TIME_MS    80
#define MOTOR_DUAL_START_STAGGER_MS     40

// ---- Screensaver jam analog ----
// Muncul saat perangkat idle (mode XiaoZhi), hilang saat wake word / tombol / kamera aktif.
// Set ENABLE_SCREENSAVER ke 0 untuk mematikan.
#define ENABLE_SCREENSAVER 1
#define SCREENSAVER_IDLE_SECONDS 30

// ---- Log baterai ----
// 0 = log "Battery: ADC=..." tiap detik dimatikan (belum ada baterai, nilainya hanya derau).
// Ubah ke 1 setelah baterai terpasang kalau mau melihat angkanya.
#define BATTERY_LOG_ENABLED 0
