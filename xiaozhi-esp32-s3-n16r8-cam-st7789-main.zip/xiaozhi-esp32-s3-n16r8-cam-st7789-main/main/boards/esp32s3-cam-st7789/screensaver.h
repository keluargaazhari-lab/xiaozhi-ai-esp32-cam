#ifndef _SCREENSAVER_H_
#define _SCREENSAVER_H_

#include <atomic>
#include <cstdint>
#include <ctime>
#include <functional>

#include <lvgl.h>

#include "display/display.h"

// Screensaver jam analog besar (latar hitam). Muncul saat perangkat idle,
// hilang saat ada aktivitas (wake word, tombol, kamera, lagu diputar).
class Screensaver {
public:
    Screensaver(Display* display, std::function<bool()> is_busy, int idle_seconds);

    // Dipanggil dari tombol: reset hitungan idle dan sembunyikan layar jam.
    void Wake();
    // true kalau layar jam sedang tampil (tekanan tombol hanya membangunkan layar).
    bool WakeIfShown();
    bool IsShown() const { return shown_.load(); }

private:
    static void TimerCb(lv_timer_t* timer);
    void Tick();
    void Show();
    void Hide();
    void UpdateClock(bool force);
    static bool TimeValid(struct tm* out);

    Display* display_;
    std::function<bool()> is_busy_;
    int64_t idle_us_;
    int64_t idle_since_us_ = 0;
    std::atomic<bool> wake_requested_{false};
    std::atomic<bool> shown_{false};

    lv_timer_t* timer_ = nullptr;
    lv_obj_t* root_ = nullptr;
    lv_obj_t* hour_hand_ = nullptr;
    lv_obj_t* minute_hand_ = nullptr;
    lv_obj_t* second_hand_ = nullptr;
    lv_obj_t* date_label_ = nullptr;

    lv_point_precise_t hour_pts_[2] = {};
    lv_point_precise_t minute_pts_[2] = {};
    lv_point_precise_t second_pts_[2] = {};

    int cx_ = 0;
    int cy_ = 0;
    int radius_ = 0;
    int last_sec_ = -1;
    int last_yday_ = -1;
    int date_y_ = 0;
};

#endif  // _SCREENSAVER_H_
